<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Portfolio_Masonry_Grid extends Harizma_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_portfolio_item';

	public function get_name() {
		return 'harizma-widget-portfolio-masonry-grid';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Masonry Grid', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent-2';
	}

	public function get_categories() {
		return array( 'harizma-dynamic' );
	}

	private $posts;

	private $posts_to_display = 8;

	private $taxonomies;

	private $load_more_data;

	public function get_posts() {

		// get class name in lowercase
		$class_name = ( new \ReflectionClass( static::class ) )->getShortName();
		$class_name = strtolower( $class_name );

		// filter to change current widget post type
		$args = apply_filters(
			'arts/elementor/' . $class_name . '/query_args',
			array(
				'post_type'      => static::$_post_type,
				'posts_per_page' => $this->posts_to_display,
				'paged'          => 1,
			)
		);

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new \WP_Query( $args );

		$this->load_more_data = array(
			'ajaxurl'      => site_url() . '/wp-admin/admin-ajax.php', // WordPress AJAX
			'posts'        => $loop->query_vars, // everything about loop is here
			'current_page' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1,
			'max_page'     => $loop->max_num_pages,
		);

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_id                        = get_the_ID();
				$post_title                     = get_the_title();
				$post_link                      = get_the_permalink();
				$post_image_id                  = get_post_thumbnail_id();
				$posts[ $counter ]['id']        = $post_id;
				$posts[ $counter ]['title']     = $post_title;
				$posts[ $counter ]['permalink'] = $post_link;
				$posts[ $counter ]['image_id']  = $post_image_id;
				$categories                     = wp_get_post_terms( $post_id, 'portfolio_category' );

				foreach ( $categories as $item ) {

					$arr = array(
						'slug' => $item->slug,
						'name' => $item->name,
					);

					// don't add the same item multiple times
					if ( ! in_array( $arr, $taxonomies ) ) {
						array_push( $taxonomies, $arr );
					}
				}

				$posts[ $counter ]['categories'] = $categories;

				$counter++;

			}

			wp_reset_postdata();

		}

		$this->posts      = $posts;
		$this->taxonomies = $taxonomies;

	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'button_title',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Load More Button: Normal Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_title_loading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Load More Button: Loading Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_title_no',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Load More Button: No More Items Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <strong>%2$s.</strong> %3$s<br><br>%4$s <a href="%5$s" target="_blank">%6$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing', 'harizma' ),
					$post_type_obj->labels->name,
					esc_html__( 'It\'s not editable directly through Elementor Page Builder.', 'harizma' ),
					esc_html__( 'You can edit or re-order your posts', 'harizma' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Load More', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_button',
			array(
				'label'   => esc_html__( 'Enable Load More', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'     => esc_html__( 'Number of Items to Display', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'number' => array(
						'min'  => 4,
						'max'  => 32,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'number',
					'size' => 8,
				),
				'condition' => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_heading',
			array(
				'label'     => esc_html__( 'Button', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title: Normal', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Load more', 'harizma' ),
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_title_loading',
			array(
				'label'       => esc_html__( 'Title: Loading', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Loading...', 'harizma' ),
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_title_no',
			array(
				'label'       => esc_html__( 'Title: No more items', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'No more items', 'harizma' ),
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'harizma' ),
					'button_solid'    => esc_html__( 'Solid', 'harizma' ),
				),
				'default'     => 'button_solid',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_accent' => esc_html__( 'Accent', 'harizma' ),
					'button_dark'   => esc_html__( 'Dark', 'harizma' ),
					'button_light'  => esc_html__( 'Light', 'harizma' ),
					'button_black'  => esc_html__( 'Black', 'harizma' ),
					'button_white'  => esc_html__( 'White', 'harizma' ),
				),
				'default'     => 'button_accent',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
				'condition'    => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filter_section',
			array(
				'label' => esc_html__( 'Filter', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_filter',
			array(
				'label'   => esc_html__( 'Enable Grid Filter', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'lightbox',
			array(
				'label'   => esc_html__( 'Enable Lightbox', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			)
		);

		$this->add_control(
			'hover_heading',
			array(
				'label'     => esc_html__( 'On Hover', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'   => esc_html__( 'Show Item Title', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'show_categories',
			array(
				'label'     => esc_html__( 'Show Item Categories', 'harizma' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'show_title' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'harizma' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'           => esc_html__( 'Columns', 'harizma' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => array(
					3  => esc_html__( 'Four Columns', 'harizma' ),
					4  => esc_html__( 'Three Columns', 'harizma' ),
					6  => esc_html__( 'Two Columns', 'harizma' ),
					12 => esc_html__( 'Single Column', 'harizma' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 6,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => esc_html__( 'Space Between', 'harizma' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 120,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 30,
				),
				'tablet_default'  => array(
					'size' => 15,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}} .grid'       => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item' => 'padding: calc({{SIZE}}{{UNIT}} / 2);',
				),
				'render_type'     => 'template',
			)
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings = $this->get_settings_for_display();

		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] ) {
			$this->posts_to_display = $settings['posts_amount']['size'];
		} else {
			$this->posts_to_display = -1;
		}

		$this->get_posts();

		$posts      = $this->posts;
		$taxonomies = $this->taxonomies;

		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		if ( $settings['enable_button'] ) {

			$this->add_render_attribute(
				'section',
				array(
					'data-ajax' => json_encode( $this->load_more_data ),
				)
			);

		}

		?>

		<div class="section-portfolio">
			<?php if ( ! empty( $taxonomies && $settings['enable_filter'] ) ) : ?>
				<div class="section-portfolio__wrapper-tabs">
					<div class="tabs filter container js-filter js-tabs">
						<div class="row justify-content-center">
							<div class="col-lg-auto col-12 tabs__item filter__item js-tabs__item js-filter__item" data-filter="*">
								<h4><?php esc_html_e( 'All', 'harizma' ); ?></h4>
							</div>
							<?php foreach ( $taxonomies as $item ) : ?>
								<div class="col-lg-auto col-12 tabs__item filter__item js-tabs__item js-filter__item" data-filter=".category-<?php echo $item['slug']; ?>">
									<h4><?php echo $item['name']; ?></h4>
								</div>
							<?php endforeach; ?>
							<div class="tabs__underline filter__underline js-tabs__underline"></div>
						</div>
					</div>
				</div>
				<!-- - grid filter-->
			<?php endif; ?>
			<?php if ( ! empty( $posts ) ) : ?>
				<div class="section-portfolio__wrapper-grid">
					<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
						<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
						<?php foreach ( $posts as $index => $item ) : ?>
							<?php if ( $item['image_id'] ) : ?>
								<?php

									$this->add_render_attribute(
										'itemAtts' . $index,
										array(
											'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ),
										)
									);

									$image      = wp_get_attachment_image_src( $item['image_id'], 'arts-800x800-crop' );
									$image_full = wp_get_attachment_image_src( $item['image_id'], 'full' );
									$categories = array();

								?>
								<?php foreach ( $item['categories'] as $taxonomy ) : ?>
									<?php
										$this->add_render_attribute(
											'itemAtts' . $index,
											array(
												'class' => 'category-' . $taxonomy->slug,
											)
										);
										$categories[] .= $taxonomy->name;
									?>
								<?php endforeach; ?>
								<div <?php echo $this->get_render_attribute_string( 'itemAtts' . $index ); ?>>
									<?php
										$this->add_render_attribute(
											'linkAtts',
											array(
												'class' => 'grid__item-link',
												'href'  => $item['permalink'],
											),
											true,
											true
										);

									if ( $settings['lightbox'] ) {
										$this->add_render_attribute(
											'linkAtts',
											array(
												'href' => $image_full[0],
												'data-elementor-open-lightbox' => 'true',
												'data-elementor-lightbox-slideshow' => $this->get_id(),
											),
											true,
											true
										);
									}

										$this->add_render_attribute(
											'lazyWrapper',
											array(
												'class' => 'lazy-masonry',
												'style' => 'padding-bottom: calc( (' . $image[2] . '/' . $image[1] . ') * 100% ); height: 0;',
											),
											true,
											true
										);
									?>
									<a <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
										<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
											<img data-src="<?php echo $image[0]; ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt="">
										</div>
										<?php if ( $settings['show_title'] || $settings['show_categories'] ) : ?>
											<div class="grid__item-info">
												<?php if ( $settings['show_title'] ) : ?>
													<h3><?php echo $item['title']; ?></h3>
												<?php endif; ?>
												<?php if ( $settings['show_categories'] ) : ?>
													<div class="grid__item-category"><?php echo implode( ' | ', $categories ); ?></div>
												<?php endif; ?>
											</div>
											<div class="overlay overlay_accent-normal grid__item-overlay"></div>
										<?php endif; ?>
									</a>
								</div>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
			<?php if ( $settings['enable_button'] ) : ?>
				<div class="section-portfolio__wrapper-button">
					<div class="container">
						<div class="row">
							<div class="col text-center">
								<?php

								$this->add_render_attribute(
									'button',
									array(
										'class' => array( 'js-load-more-button', 'button', $settings['button_style'], $settings['button_color'], $settings['button_shadow'] ),
										'href'  => '#',
										'data-load-more-text-load' => $settings['button_title'],
									)
								);

								if ( ! empty( $settings['button_title_loading'] ) ) {
									$this->add_render_attribute(
										'button',
										array(
											'data-load-more-text-loading' => $settings['button_title_loading'],
										)
									);
								}

								if ( ! empty( $settings['button_title_no'] ) ) {
									$this->add_render_attribute(
										'button',
										array(
											'data-load-more-text-no' => $settings['button_title_no'],
										)
									);
								}

								?>
								<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><?php echo $settings['button_title']; ?></a>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
