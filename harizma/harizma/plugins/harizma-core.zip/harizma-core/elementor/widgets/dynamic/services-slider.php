<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Services_Slider extends Harizma_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_service';

	public function get_name() {
		return 'harizma-widget-services-slider';
	}

	public function get_title() {
		return esc_html__( 'Services Slider', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent-2';
	}

	public function get_categories() {
		return array( 'harizma-dynamic' );
	}

	protected function register_controls() {
		$posts         = $this->get_posts();
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <strong>%2$s.</strong> %3$s<br><br>%4$s <a href="%5$s" target="_blank">%6$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing', 'harizma' ),
					$post_type_obj->labels->name,
					esc_html__( 'It\'s not editable directly through Elementor Page Builder.', 'harizma' ),
					esc_html__( 'You can edit or re-order your posts', 'harizma' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'     => esc_html__( 'Number of Posts to Display (0 for all)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'number',
					'size' => 0,
				),
				'separator' => 'after',
			)
		);

		foreach ( $posts as $index => $item ) {
			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'harizma' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'harizma' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Icon
			 */
			$id = 'icon' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Icon', 'harizma' ),
					'type'       => Controls_Manager::ICON,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'separator'  => 'after',
				)
			);

		}

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts_to_display();
		?>
		<div class="container section-services-tabs__wrapper-tabs bg-black-2 color-white">
			<div class="tabs js-tabs tabs_pt tabs_pb">
				<div class="row justify-content-center">
					<?php foreach ( $posts as $item ) : ?>
						<?php
							$post_id = $item['id'];
							$icon    = $settings[ 'icon' . $post_id ];
						?>
						<div class="tabs__item js-tabs__item col-md-2 col-sm-4 col-6">
							<div class="tabs__icon <?php echo $icon; ?>"></div>
							<h4><?php echo $item['title']; ?></h4>
						</div>
					<?php endforeach; ?>
					<div class="tabs__underline js-tabs__underline"></div>
				</div>
			</div>
		</div>
		<!-- - tabs (slider content selector) -->
		<div class="container section-services-tabs__content">
			<div class="swiper swiper-container slider slider-services js-slider-services">
				<div class="swiper-wrapper">
					<?php foreach ( $posts as $item ) : ?>
						<div class="swiper-slide slider-services__slide">
							<div class="row justify-content-between">
								<?php if ( ! empty( $item['content'] ) ) : ?>
									<div class="col-lg-5">
										<div class="slider-services__header">
											<div class="slider-services__headline"></div>
											<h4><?php echo $item['content']; ?></h4>
										</div>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $item['description'] ) ) : ?>
									<div class="col-lg-6">
										<div class="slider-services__wrapper-text">
											<p><?php echo $item['description']; ?></p>
										</div>
									</div>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
