<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Portfolio_Slider extends Harizma_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_portfolio_item';

	public function get_name() {
		return 'harizma-widget-portfolio-slider';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Slider', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent-2';
	}

	public function get_categories() {
		return array( 'harizma-dynamic' );
	}

	private function get_posts_by_term( $term = null ) {
		$args = array(
			'post_type'      => static::$_post_type,
			'posts_per_page' => -1,
			'tax_query'      => array(
				array(
					'taxonomy' => 'portfolio_category',
					'field'    => 'slug',
					'terms'    => $term,
				),
			),
		);

		$posts   = array();
		$counter = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$post_id                        = get_the_ID();
				$post_title                     = get_the_title();
				$post_link                      = get_the_permalink();
				$post_image_id                  = get_post_thumbnail_id();
				$posts[ $counter ]['id']        = $post_id;
				$posts[ $counter ]['title']     = $post_title;
				$posts[ $counter ]['permalink'] = $post_link;
				$posts[ $counter ]['image_id']  = $post_image_id;
				$posts[ $counter ]['content']   = get_post_meta( $posts[ $counter ]['id'], 'additonal_content_description', true );

				$counter++;

			}

			wp_reset_postdata();

		}

		return $posts;
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Section Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_title',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Link', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );
		$terms         = static::get_terms( 'portfolio_category' );

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Section heading', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Check our latest projects', 'harizma' ),
			)
		);

		$this->add_control(
			'cta_button_label',
			array(
				'label'   => esc_html__( 'Project button label', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Learn more', 'harizma' ),
			)
		);

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <strong>%2$s.</strong> %3$s<br><br>%4$s <a href="%5$s" target="_blank">%6$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing', 'harizma' ),
					$post_type_obj->labels->name,
					esc_html__( 'It\'s not editable directly through Elementor Page Builder.', 'harizma' ),
					esc_html__( 'You can edit or re-order your posts', 'harizma' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'categories_section',
			array(
				'label' => esc_html__( 'Categories', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		if ( ! empty( $terms ) ) {
			foreach ( $terms as $item ) {

				$id = 'heading_icon' . $item->slug;
				$this->add_control(
					$id,
					array(
						'label'     => $item->name,
						'type'      => Controls_Manager::HEADING,
						'separator' => 'before',
					)
				);

				$id = 'icon' . $item->slug;
				$this->add_control(
					$id,
					array(
						'label' => esc_html__( 'Icon', 'harizma' ),
						'type'  => Controls_Manager::ICON,
					)
				);

				$id = 'enable' . $item->slug;
				$this->add_control(
					$id,
					array(
						'label'        => esc_html__( 'Enable Category', 'harizma' ),
						'type'         => Controls_Manager::SWITCHER,
						'return_value' => 'yes',
						'default'      => 'yes',
					)
				);

			}
		}

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_button',
			array(
				'label'   => esc_html__( 'Show button at the bottom of section', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'View Portfolio', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Button', 'harizma' ),
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'harizma' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
				'condition'     => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'harizma' ),
					'button_solid'    => esc_html__( 'Solid', 'harizma' ),
				),
				'default'     => 'button_solid',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_accent' => esc_html__( 'Accent', 'harizma' ),
					'button_dark'   => esc_html__( 'Dark', 'harizma' ),
					'button_light'  => esc_html__( 'Light', 'harizma' ),
					'button_black'  => esc_html__( 'Black', 'harizma' ),
					'button_white'  => esc_html__( 'White', 'harizma' ),
				),
				'default'     => 'button_accent',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
				'condition'    => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$taxonomies = static::get_terms( 'portfolio_category' );

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'button_title' );
		?>
		<div class="section-latest-projects bg-light">
			<div class="section-latest-projects__wrapper-tabs bg-black-2 color-white">
				<div class="container">
					<div class="tabs js-tabs">
						<?php if ( ! empty( $settings['heading'] ) ) : ?>
							<div class="row tabs__header">
								<div class="col">
									<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
								</div>
							</div>
						<?php endif; ?>
						<div class="row justify-content-center">
							<?php foreach ( $taxonomies as $item ) : ?>
								<?php if ( $settings[ 'enable' . $item->slug ] ) : ?>
									<?php
										$this->add_render_attribute(
											'itemFilter',
											array(
												'class' => array( 'tabs__icon', $settings[ 'icon' . $item->slug ] ),
												'data-filter' => $item->slug,
											),
											true,
											true
										);
									?>
									<div class="tabs__item js-tabs__item col-md-2 col-sm-4 col-6">
										<div <?php echo $this->get_render_attribute_string( 'itemFilter' ); ?>></div>
										<h4><?php echo $item->name; ?></h4>
									</div>
								<?php endif; ?>
							<?php endforeach; ?>
							<div class="tabs__underline js-tabs__underline"></div>
						</div>
					</div>
				</div>
			</div>
			<!-- - tabs (sliders group selector) -->
			<div class="swiper swiper-container js-slider-projects">
				<div class="swiper-wrapper">
					<?php foreach ( $taxonomies as $item ) : ?>
						<?php if ( $settings[ 'enable' . $item->slug ] ) : ?>
							<?php $posts = $this->get_posts_by_term( $item->slug ); ?>
							<div class="swiper-slide">
								<div class="section-latest-projects__inner">
									<div class="section-latest-projects__wrapper-content">
										<div class="slider slider-project-content swiper swiper-container js-slider-project-content">
											<div class="swiper-wrapper">
												<?php foreach ( $posts as $post ) : ?>
													<?php $mask_id = uniqid( $post['id'] ); ?>
													<?php $image_full = wp_get_attachment_image_src( $post['image_id'], 'arts-1920x840-crop' ); ?>
													<div class="swiper-slide slider-project-content__slide">
														<div class="slider-project-content__wrapper-image">
															<svg data-swiper-parallax data-swiper-parallax-x="50%" data-swiper-parallax-opacity="0" class="slider-project-content__mask" version="1.1" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 1920 840" preserveAspectRatio="xMidYMid slice">
															<defs>
															<mask id="mask-<?php echo $mask_id; ?>" x="0" y="0">
															<polygon points="0 0 1790 0 1380 420 1790 840 0 840" fill="#ffffff"></polygon>
															</mask>
															</defs>
															<polyline stroke="#ffffff" stroke-width="10" points="1820 -15 1398 420 1820 855" fill="none"></polyline>
															<image xlink:href="<?php echo $image_full[0]; ?>" mask="url(#mask-<?php echo $mask_id; ?>)" width="100%" height="100%" x="0" y="0" />
															</svg>
														</div>
														<!-- - item image in SVG mask-->
														<div class="slider-project-content__wrapper-overlay" data-swiper-parallax="data-swiper-parallax" data-swiper-parallax-x="-200%">
															<div class="slider-project-content__diagonal-overlay"></div>
														</div>
														<!-- - item overlay-->
														<div class="container slider-project-content__wrapper-content color-white">
															<div class="row">
																<div class="col-lg-10 offset-lg-1 offset-xl-0">
																	<h3><?php echo $post['title']; ?></h3>
																	<?php if ( ! empty( $post['content'] ) ) : ?>
																		<p><?php echo $post['content']; ?></p>
																	<?php endif; ?>
																</div>
															</div>
															<?php if ( ! empty( $settings['cta_button_label'] ) ) : ?>
																<div class="slider-project-content__wrapper-button">
																	<a class="button button_white button_arrow" href="<?php echo $post['permalink']; ?>">
																		<span class="button__text button__text_line button__text_line-right"><?php echo $settings['cta_button_label']; ?></span>
																		<img class="button__icon" src="<?php echo get_theme_file_uri( 'img/general/triangle-right.svg' ); ?>"  alt=""/>
																	</a>
																</div>
															<?php endif; ?>
															<!-- - item button-->
														</div>
														<!-- - item content-->
													</div>
												<?php endforeach; ?>
											</div>
											<?php if ( count( $posts ) > 1 ) : ?>
												<div class="slider-project-content__wrapper-slider-nav">
													<div class="slider-nav js-slider-project-content__nav">
														<div class="slider-nav__dot slider-nav__dot_active"></div>
														<div class="slider-nav__dot"></div>
														<div class="slider-nav__dot"></div>
													</div>
												</div>
												<!-- - slider dots -->
											<?php endif; ?>
											<div class="slider__prev slider-project-content__prev js-slider-project-content__prev"></div>
											<div class="slider__next slider-project-content__next js-slider-project-content__next"></div>
											<!-- - slider arrows -->
										</div>
									</div>
									<!-- - slider main images & content -->
									<div class="section-latest-projects__wrapper-backgrounds">
										<div class="slider slider-project-backgrounds swiper swiper-container js-slider-project-backgrounds">
											<div class="swiper-wrapper">
												<?php if ( count( $posts ) > 1 ) : ?>
													<?php
														// make first item as last item
														$first_item = array_shift( $posts );
														array_push( $posts, $first_item );
													?>
													<?php foreach ( $posts as $post ) : ?>
														<?php $image_full = wp_get_attachment_image_src( $post['image_id'], 'arts-1920x840-crop' ); ?>
														<div class="swiper-slide slider-project-backgrounds__slide">
															<img class="of-cover swiper-lazy" data-swiper-parallax="data-swiper-parallax" data-swiper-parallax-x="-50%" data-src="<?php echo $image_full[0]; ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt=""/>
														</div>
													<?php endforeach; ?>
												<?php endif; ?>
											</div>
										</div>
									</div>
									<!-- - slider backgrounds -->
								</div>
							</div>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
				<!-- - slider main images & content -->
			</div>
			<!-- - groups of sliders-->
			<?php if ( ! empty( $settings['button_title'] && $settings['enable_button'] ) ) : ?>
				<div class="section-latest-projects__wrapper-button">
						<?php
						$this->add_render_attribute(
							'button',
							array(
								'class' => array( 'button', $settings['button_style'], $settings['button_color'], $settings['button_shadow'] ),
								'href'  => $settings['button_link']['url'],
							)
						);

						if ( $settings['button_link']['is_external'] ) {
							$this->add_render_attribute( 'button', 'target', '_blank' );
						}

						if ( $settings['button_link']['nofollow'] ) {
							$this->add_render_attribute( 'button', 'rel', 'nofollow' );
						}
						?>
					<div class="container">
						<div class="row">
							<div class="col text-center">
								<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( 'button_title' ); ?>><?php echo $settings['button_title']; ?></span></a>
							</div>
						</div>
					</div>
				</div>
				<!-- - view more -->
			<?php endif; ?>
		</div>
		<?php
	}
}
