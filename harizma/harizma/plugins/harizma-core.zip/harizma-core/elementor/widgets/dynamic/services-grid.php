<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Services_Grid extends Harizma_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_service';

	public function get_name() {
		return 'harizma-widget-services-grid';
	}

	public function get_title() {
		return esc_html__( 'Services Grid', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-sitemap hrz icon-harizma-logo hrz_accent-2';
	}

	public function get_categories() {
		return array( 'harizma-dynamic' );
	}

	protected function register_controls() {
		$posts         = $this->get_posts();
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <strong>%2$s.</strong> %3$s<br><br>%4$s <a href="%5$s" target="_blank">%6$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing', 'harizma' ),
					$post_type_obj->labels->name,
					esc_html__( 'It\'s not editable directly through Elementor Page Builder.', 'harizma' ),
					esc_html__( 'You can edit or re-order your posts', 'harizma' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'     => esc_html__( 'Number of Posts to Display (0 for all)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'number',
					'size' => 0,
				),
				'separator' => 'after',
			)
		);

		foreach ( $posts as $index => $item ) {
			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'harizma' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'harizma' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Icon
			 */
			$id = 'icon' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Icon', 'harizma' ),
					'type'       => Controls_Manager::ICON,
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
					'separator'  => 'after',
				)
			);

		}

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts_to_display();
		$counter  = 0;

		$this->add_render_attribute( 'section', 'class', array( 'section', 'section-services' ) );
		?>
		<?php if ( ! empty( $posts ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div class="section__content container-fluid">
					<div class="row">
						<?php foreach ( $posts as $item ) : ?>
							<?php
								$post_id = $item['id'];
								$icon    = array_key_exists( 'icon' . $post_id, $settings ) ? $settings[ 'icon' . $post_id ] : '';
								$counter++;
								$counter_string = $counter < 10 ? '0' . $counter : $counter;
							?>
							<div class="col-xl col-12 col-sm-6 col-lg-4 section-services__wrapper-service js-service-hover" data-services-post-id="<?php echo $post_id; ?>">
								<div class="figure-service">
									<div class="figure-service__counter"><?php echo $counter_string; ?></div>
									<?php if ( $icon ) : ?>
										<div class="figure-service__icon <?php echo $icon; ?>"></div>
									<?php endif; ?>
									<?php if ( ! empty( $item['title'] ) ) : ?>
										<h3><?php echo $item['title']; ?></h3>
									<?php endif; ?>
									<div class="figure-service__headline"></div>
									<?php if ( ! empty( $item['content'] ) ) : ?>
										<p><?php echo $item['content']; ?></p>
									<?php endif; ?>
									<div class="figure-service__wrapper-button">
										<a class="button button_white button_bordered button_circle elegant-icons arrow_right" href="<?php echo $item['permalink']; ?>"></a>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<div class="section-services__wrapper-background">
					<?php foreach ( $posts as $item ) : ?>
						<?php
							$post_id  = $item['id'];
							$post_img = $item['image_id'];
						?>
						<?php if ( ! empty( $post_img ) ) : ?>
							<div class="section-services__background js-service-hover__background lazy-bg" data-src="<?php echo wp_get_attachment_url( $post_img ); ?>" data-services-background-for="<?php echo $post_id; ?>"></div>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
				<div class="overlay overlay_black"></div>
			</div>
		<?php endif; ?>
		<?php
	}
}
