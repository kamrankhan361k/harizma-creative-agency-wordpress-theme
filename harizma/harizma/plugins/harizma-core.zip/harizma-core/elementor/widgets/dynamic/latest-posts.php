<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Latest_Posts extends Harizma_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'post';

	public function get_name() {
		return 'harizma-widget-latest-posts';
	}

	public function get_title() {
		return esc_html__( 'Latest Posts', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent-2';
	}

	public function get_categories() {
		return array( 'harizma-dynamic' );
	}

	protected function register_controls() {
		$posts         = $this->get_posts();
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );

		// posts toggles & posts amount
		$this->add_controls_posts_toggles();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Excerpt length
		 */
		$this->add_control(
			'excerpt_length',
			array(
				'label'   => esc_html__( 'Excerpt length (symbols)', 'harizma' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 10,
						'max'  => 100,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 20,
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts_to_display();
		?>
		<?php if ( ! empty( $posts ) ) : ?>
			<div class="container section__content">
				<div class="row">
					<?php foreach ( $posts as $item ) : ?>
						<div class="col-lg-4">
							<article class="figure-post">
								<?php if ( $item['image_id'] ) : ?>
									<?php
										$img = wp_get_attachment_image_src( $item['image_id'], 'arts-375x290-crop' );

										$this->add_render_attribute(
											'lazyWrapper',
											array(
												'class' => 'lazy',
												'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
											),
											true,
											true
										);

									?>
									<a class="figure-post__wrapper-thumbnail" href="<?php echo $item['permalink']; ?>">
										<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
											<img data-src="<?php echo $img[0]; ?>" src="#" alt=""/>
										</div>
									</a>
								<?php endif; ?>
								<div class="figure-post__inner">
									<div class="figure-post__wrapper-content figure-post__wrapper-content_pr">
										<?php if ( ! empty( $item['title'] ) ) : ?>
											<h3><a href="<?php echo $item['permalink']; ?>"><?php echo $item['title']; ?></a></h3>
										<?php endif; ?>
										<?php if ( ! empty( $item['excerpt'] ) ) : ?>
											<p><?php echo wp_trim_words( $item['excerpt'], $settings['excerpt_length']['size'] ); ?></p>
										<?php endif; ?>
									</div>
									<div class="figure-post__footer">
										<ul class="post-meta post-date">
											<li class="post-meta__item">
												<div class="post-meta__item-icon elegant-icons icon_clock_alt"></div><span class="post-meta__item-text"></span>&nbsp;<a class="post-meta__link" href="<?php echo $item['permalink']; ?>"><?php echo $item['date']; ?></a>
											</li>
										</ul>
									</div>
								</div>
							</article>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		<?php
	}
}
