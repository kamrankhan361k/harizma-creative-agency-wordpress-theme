<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Base extends Widget_Base {
	protected static $_instance;

	public static function instance() {
		if ( is_null( static::$_instance ) ) {
			static::$_instance = new static();
		}

		return static::$_instance;
	}

	public function get_name() {}

	public function get_title() {}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	protected static $_posts, $_post_type, $_terms, $_data_static_fields = array(), $_load_more_data = array();

	/**
	 * WordPress DB query for the posts
	 *
	 * @return void
	 */
	protected static function _get_posts() {

		// get class name in lowercase
		$class_name = ( new \ReflectionClass( static::class ) )->getShortName();
		$class_name = strtolower( $class_name );

		// filter to change current widget post type
		$args = apply_filters(
			'arts/elementor/' . $class_name . '/query_args',
			array(
				'post_type'      => static::$_post_type,
				'posts_per_page' => -1,
			)
		);

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$posts[ $counter ]['id']          = get_the_ID();
				$posts[ $counter ]['title']       = get_the_title();
				$posts[ $counter ]['permalink']   = get_the_permalink();
				$posts[ $counter ]['image_id']    = get_post_thumbnail_id();
				$posts[ $counter ]['date']        = get_the_date();
				$posts[ $counter ]['content']     = get_post_meta( $posts[ $counter ]['id'], 'additonal_content_description', true );
				$posts[ $counter ]['description'] = get_post_meta( $posts[ $counter ]['id'], 'additonal_content_additonal-description', true );
				$posts[ $counter ]['excerpt']     = get_the_content();
				$categories                       = wp_get_post_terms( $posts[ $counter ]['id'], 'portfolio_category' );

				foreach ( $categories as $item ) {

					$arr = array(
						'slug' => $item->slug,
						'name' => $item->name,
					);

					// don't add the same item multiple times
					if ( ! in_array( $arr, $taxonomies ) ) {
						array_push( $taxonomies, $arr );
					}
				}

				$posts[ $counter ]['categories'] = $categories;

				$counter++;

			}

			wp_reset_postdata();

		}

		static::$_posts = $posts;
	}

	/**
	 * Get Taxonomies
	 */
	public static function get_terms( $term = null ) {
		if ( ! $term ) {
			return array();
		}

		if ( is_null( static::$_posts ) ) {
			static::_get_posts();
		}

		if ( is_null( static::$_terms ) ) {
			static::$_terms = get_terms(
				$term,
				array(
					'hide_empty' => true,
				)
			);
		}

		return static::$_terms;
	}

	/**
	 * Get all posts by a pre-set type
	 *
	 * @return array
	 */
	public function get_posts() {
		if ( is_null( static::$_posts ) ) {
			static::_get_posts();
		}

		return static::$_posts;
	}

	/**
	 * Filter out disabled posts
	 *
	 * @return array
	 */
	public function get_posts_to_display() {
		$posts    = $this->get_posts();
		$settings = $this->get_settings_for_display();
			// limit posts amount
		if ( is_array( $settings['posts_amount'] ) && $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		// only "enabled" posts
		$posts = array_filter(
			$posts,
			function( $item ) {
				$settings = $this->get_settings_for_display();
				return ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] );
			}
		);

		return $posts;
	}

	/**
	 * Used for widgets with dynamically fetched posts
	 * Prints posts toggles set in the control panel
	 *
	 * @return void
	 */
	public function add_controls_posts_toggles() {
		$posts         = $this->get_posts();
		$post_type     = static::$_post_type;
		$post_type_obj = get_post_type_object( $post_type );

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Posts', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		if ( ! $posts ) {
			$this->end_controls_section();
			return;
		}

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <strong>%2$s.</strong> %3$s<br><br>%4$s <a href="%5$s" target="_blank">%6$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing', 'harizma' ),
					$post_type_obj->labels->name,
					esc_html__( 'It\'s not editable directly through Elementor Page Builder.', 'harizma' ),
					esc_html__( 'You can edit or re-order your posts', 'harizma' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'     => esc_html__( 'Posts to Display (0 for all)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default'   => array(
					'unit' => 'number',
					'size' => 0,
				),
				'separator' => 'after',
			)
		);

		foreach ( $posts as $index => $item ) {
			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'harizma' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'separator'  => 'before',
					'conditions' => array(
						'relation' => 'and',
						'terms'    => array(
							array(
								'relation' => 'or',
								'terms'    => array(
									array(
										'name'     => 'posts_amount[size]',
										'operator' => '>',
										'value'    => $index,
									),
									array(
										'name'     => 'posts_amount[size]',
										'operator' => '<=',
										'value'    => '0',
									),
								),
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'harizma' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'and',
						'terms'    => array(
							array(
								'relation' => 'or',
								'terms'    => array(
									array(
										'name'     => 'posts_amount[size]',
										'operator' => '>',
										'value'    => $index,
									),
									array(
										'name'     => 'posts_amount[size]',
										'operator' => '<=',
										'value'    => '0',
									),
								),
							),
						),
					),
				)
			);

		}

		$this->end_controls_section();
	}
}
