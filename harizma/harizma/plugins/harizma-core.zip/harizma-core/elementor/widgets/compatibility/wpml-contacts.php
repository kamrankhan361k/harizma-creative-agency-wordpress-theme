<?php

class WPML_Elementor_Harizma_Widget_Contacts extends WPML_Elementor_Module_With_Items {
	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'contacts';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array( 'contact', 'info' );
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'contact':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Contact', 'harizma' ), esc_html__( 'Label', 'harizma' ) );
			case 'info':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Contact', 'harizma' ), esc_html__( 'Info', 'harizma' ) );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'contact':
				return 'LINE';
			case 'info':
				return 'LINE';

			default:
				return '';
		}
	}
}
