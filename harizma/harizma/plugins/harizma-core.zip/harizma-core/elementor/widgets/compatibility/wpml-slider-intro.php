<?php

class WPML_Elementor_Harizma_Widget_Slider_Intro extends WPML_Elementor_Module_With_Items {
	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'properties';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array( 'heading', 'description', 'button_title', 'button_link' );
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'heading':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Intro', 'harizma' ), esc_html__( 'Heading', 'harizma' ) );
			case 'description':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Intro', 'harizma' ), esc_html__( 'Description', 'harizma' ) );
			case 'button_title':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Intro', 'harizma' ), esc_html__( 'Button Title', 'harizma' ) );
			case 'button_link':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Intro', 'harizma' ), esc_html__( 'Button Link', 'harizma' ) );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'heading':
				return 'AREA';
			case 'description':
				return 'AREA';
			case 'button_title':
				return 'LINE';
			case 'button_link':
				return 'LINE';

			default:
				return '';
		}
	}
}
