<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Header_Section extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-header-section';
	}

	public function get_title() {
		return esc_html__( 'Header Section', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'subheading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Label', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'text',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Text', 'harizma' ) ),
					'editor_type' => 'AREA',
				),
				array(
					'field'       => 'link_text',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Link Text', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Link URL', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'subheading',
			array(
				'label'       => esc_html__( 'Label', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Label...', 'harizma' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Heading...', 'harizma' ),
			)
		);

		$this->add_control(
			'text',
			array(
				'label'       => esc_html__( 'Text', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => esc_html__( 'Heading details...', 'harizma' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'link_section',
			array(
				'label' => esc_html__( 'Link', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'link_text',
			array(
				'label'       => esc_html__( 'Text', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'link',
			array(
				'label'         => esc_html__( 'URL', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'subheading' );
		$this->add_inline_editing_attributes( 'text' );
		$this->add_inline_editing_attributes( 'link_text' );

		$this->add_render_attribute(
			'link',
			array(
				'class' => array( 'link' ),
				'href'  => $settings['link']['url'],
			)
		);

		if ( $settings['link']['is_external'] ) {
			$this->add_render_attribute( 'link', 'target', '_blank' );
		}

		if ( $settings['link']['nofollow'] ) {
			$this->add_render_attribute( 'link', 'rel', 'nofollow' );
		}

		?>
		<header class="section__header-container container">
			<?php if ( ! empty( $settings['subheading'] ) ) : ?>
				<div class="section__header-subheading">
					<span <?php echo $this->get_render_attribute_string( 'subheading' ); ?>><?php echo $settings['subheading']; ?></span>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['heading'] ) || ! empty( $settings['link_text'] ) ) : ?>
				<div class="row justify-content-between align-items-center flex-wrap">
					<?php if ( ! empty( $settings['heading'] ) ) : ?>
						<div class="col-sm-auto col-12">
							<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['link_text'] ) ) : ?>
						<div class="col-sm-auto">
							<a <?php echo $this->get_render_attribute_string( 'link' ); ?>>
								<div class="link__text">
									<span <?php echo $this->get_render_attribute_string( 'link_text' ); ?>><?php echo $settings['link_text']; ?></span>
								</div>
								<div class="link__icon elegant-icons arrow_right"></div>
							</a>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['text'] ) ) : ?>
				<p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo $settings['text']; ?></p>
			<?php endif; ?>
		</header>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'heading' );
			view.addInlineEditingAttributes( 'subheading' );
			view.addInlineEditingAttributes( 'text' );
			view.addInlineEditingAttributes( 'link_text' );

			view.addRenderAttribute(
				'link', {
					'class': [ 'link' ],
					'href': settings.link.url,
				}
			);

			if ( settings.link.is_external ) {
				view.addRenderAttribute( 'link', 'target', '_blank' );
			}

			if ( settings.link.nofollow ) {
				view.addRenderAttribute( 'link', 'rel', 'nofollow' );
			}
		#>

		<header class="section__header-container container">
			<# if ( settings.subheading ) { #>
				<div class="section__header-subheading">
					<span {{{ view.getRenderAttributeString( 'subheading' ) }}}>{{{ settings.subheading }}}</span>
				</div>
			<# } #>
			<# if ( settings.heading || settings.link_text ) { #>
				<div class="row justify-content-between align-items-center flex-wrap">
					<# if ( settings.heading ) { #>
						<div class="col-sm-auto col-12">
							<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
						</div>
					<# } #>
					<# if ( settings.link_text ) { #>
						<div class="col-sm-auto">
							<a {{{ view.getRenderAttributeString( 'link' ) }}}>
								<div class="link__text">
									<span {{{ view.getRenderAttributeString( 'link_text' ) }}} >{{{ settings.link_text }}}</span>
								</div>
								<div class="link__icon elegant-icons arrow_right"></div>
							</a>
						</div>
					<# } #>
				</div>
			<# } #>
			<# if ( settings.text ) { #>
				<p {{{ view.getRenderAttributeString( 'text' ) }}}>{{{ settings.text }}}</p>
			<# } #>
		</header>

		<?php
	}
}
