<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Logos_Grid extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-logos-grid';
	}

	public function get_title() {
		return esc_html__( 'Logos Grid', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Logos', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'gallery',
			array(
				'label' => esc_html__( 'Add logos', 'harizma' ),
				'type'  => Controls_Manager::GALLERY,
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="container">
			<div class="row justify-content-between align-items-center text-center">
				<?php if ( ! empty( $settings['gallery'] ) ) : ?>
					<?php foreach ( $settings['gallery'] as $image ) : ?>
						<?php
							$img = wp_get_attachment_image_src( $image['id'], 'full' );
							$this->add_render_attribute(
								'lazyWrapper',
								array(
									'class' => 'lazy',
									'style' => 'height: ' . $img[2] . 'px; width: ' . $img[1] . 'px;',
								),
								true,
								true
							);
						?>
						<div class="col-lg-auto col-md-4 col-sm-6 aside-logos__wrapper-logo">
							<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
								<img data-src="<?php echo $img[0]; ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt=""/>
							</div>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<div class="section aside aside-logos section_mt section_mb">
			<div class="container">
				<div class="row justify-content-between align-items-center text-center">
					<# if ( settings.gallery.length ) { #>
						<# _.each( settings.gallery, function( image ) { #>
							<div class="col-lg-auto col-md-4 col-sm-6 aside-logos__wrapper-logo">
								<img class="lazy" data-src="{{{ image.url }}}" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt=""/>
							</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</div>
		<?php
	}
}
