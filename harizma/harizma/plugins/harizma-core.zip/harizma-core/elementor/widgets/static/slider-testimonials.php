<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Slider_Testimonials extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-slider-testimonials';
	}

	public function get_title() {
		return esc_html__( 'Slider Testimonials', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {

		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(),
			'integration-class' => 'WPML_Harizma_Widget_Slider_Testimonials',
		);

		return $widgets;

	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Testimonials', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'name',
			array(
				'label'   => esc_html__( 'Author Name & Info', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'John Doe, CEO of Company', 'harizma' ),
			)
		);

		$repeater->add_control(
			'text',
			array(
				'label'   => esc_html__( 'Text', 'harizma' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 10,
				'default' => esc_html__( 'Testimonial text...', 'harizma' ),
			)
		);

		$this->add_control(
			'testimonials',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ name }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			array(
				'label' => esc_html__( 'Slider', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_dots',
			array(
				'label'   => esc_html__( 'Enable Dots', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => esc_html__( 'Autoplay', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'harizma' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 1200,
				),
			)
		);

		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'harizma' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => array(
					'ltr' => array(
						'title' => esc_html__( 'Left to Right', 'harizma' ),
						'icon'  => 'eicon-chevron-double-right',
					),
					'rtl' => array(
						'title' => esc_html__( 'Right to Left', 'harizma' ),
						'icon'  => 'eicon-chevron-double-left',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'swiper',
			array(
				'class'      => array(
					'slider',
					'slider-testimonials',
					'slider-testimonials_elementor',
					'swiper',
					'swiper-container',
					'js-slider-testimonials',
				),
				'data-speed' => is_array( $settings['speed'] ) ? $settings['speed']['size'] : 0,
				'dir'        => $settings['direction'],
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => is_array( $settings['autoplay_delay'] ) ? $settings['autoplay_delay']['size'] : 0,
				)
			);
		}

		$num_slides = count( $settings['testimonials'] );
		?>
		<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
			<div class="swiper-wrapper">
				<?php if ( ! empty( $settings['testimonials'] ) ) : ?>
					<?php foreach ( $settings['testimonials'] as $index => $item ) : ?>
						<?php
							$keyName = $this->get_repeater_setting_key( 'name', 'testimonials', $index );
							$keyText = $this->get_repeater_setting_key( 'text', 'testimonials', $index );
							$this->add_inline_editing_attributes( $keyName );
							$this->add_inline_editing_attributes( $keyText );
						?>
						<div class="swiper-slide slider-testimonials__slide text-center">
							<?php if ( ! empty( $item['text'] ) ) : ?>
								<p <?php echo $this->get_render_attribute_string( $keyText ); ?>><?php echo $item['text']; ?></p>
							<?php endif; ?>
							<?php if ( ! empty( $item['name'] ) ) : ?>
								<div class="slider-testimonials__name">
									<span <?php echo $this->get_render_attribute_string( $keyName ); ?>><?php echo $item['name']; ?></span>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
			<?php if ( $num_slides > 1 && $settings['enable_dots'] ) : ?>
				<div class="slider-testimonials__wrapper-slider-nav">
					<div class="slider-nav js-slider-testimonials__nav">
						<div class="slider-nav__dot slider-nav__dot_active"></div>
						<div class="slider-nav__dot"></div>
						<div class="slider-nav__dot"></div>
					</div>
				</div>
			<!-- - slider dots -->
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			var num_slides = settings.testimonials.length;

			view.addRenderAttribute('swiper', {
				'class': [
					'slider',
					'slider-testimonials',
					'slider-testimonials_elementor',
					'swiper',
					'swiper-container',
					'js-slider-testimonials',
				],
				'data-speed': settings.speed.size,
				'dir': settings.direction,
			});

			if ( settings.enable_autoplay ) {
				view.addRenderAttribute(
					'swiper', {
						'data-autoplay-enabled': 'true',
						'data-autoplay-delay': settings.autoplay_delay.size,
					}
				);
			}
		#>
		<div class="section section-testimonials">
			<div {{{ view.getRenderAttributeString( 'swiper' ) }}}>
				<div class="swiper-wrapper">
					<# if ( settings.testimonials.length ) { #>
						<# _.each( settings.testimonials, function(item, index) { #>
							<#
								var keyName = view.getRepeaterSettingKey( 'name', 'testimonials', index );
								var keyText = view.getRepeaterSettingKey( 'text', 'testimonials', index );
								view.addInlineEditingAttributes( keyName );
								view.addInlineEditingAttributes( keyText );
							#>
							<div class="swiper-slide slider-testimonials__slide text-center">
								<# if ( item.text ) { #>
									<p {{{ view.getRenderAttributeString( keyText ) }}}>{{{ item.text }}}</p>
								<# } #>
								<# if ( item.name ) { #>
									<div class="slider-testimonials__name">
										<span {{{ view.getRenderAttributeString( keyName ) }}}>{{{ item.name }}}</span>
									</div>
								<# } #>
							</div>
						<# }); #>
					<# } #>
				</div>
				<# if ( num_slides > 1 && settings.enable_dots ) { #>
					<div class="slider-testimonials__wrapper-slider-nav">
						<div class="slider-nav js-slider-testimonials__nav">
							<div class="slider-nav__dot slider-nav__dot_active"></div>
							<div class="slider-nav__dot"></div>
							<div class="slider-nav__dot"></div>
						</div>
					</div>
				<!-- - slider dots -->
				<# } #>
			</div>
		</div>
		<?php
	}
}
