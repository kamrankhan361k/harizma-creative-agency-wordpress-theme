<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Google_Map extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-google-map';
	}

	public function get_title() {
		return esc_html__( 'Google Map', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	private function check_api_key() {
		$gmap = get_option( 'arts_gmap' );
		return isset( $gmap['key'] ) && ! empty( $gmap['key'] );
	}

	public function get_script_depends() {

		$gmap = get_option( 'arts_gmap' );

		if ( isset( $gmap['key'] ) && ! empty( $gmap['key'] ) ) {
			wp_enqueue_script( 'googlemap', '//maps.googleapis.com/maps/api/js?key=' . $gmap['key'], array(), null, true );
		}

		return array( 'googlemap' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(),
			'integration-class' => 'WPML_Elementor_Harizma_Widget_Google_Map',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		/**
		 * Section Markers
		 */
		$this->start_controls_section(
			'markers_section',
			array(
				'label' => esc_html__( 'Markers', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'is_key',
			array(
				'type'    => Controls_Manager::HIDDEN,
				'default' => $this->check_api_key(),
			)
		);

		$this->add_control(
			'message_api',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <a href="https://developers.google.com/maps/documentation/javascript/tutorial#api-key-billing-errors" target="_blank">%2$s</a><br><br>%3$s <a href="%4$s" target="_blank">%5$s</a> %6$s',
					esc_html__( 'To make this widget work properly you need to obtain', 'harizma' ),
					esc_html__( 'an API key from Google', 'harizma' ),
					esc_html__( 'If you already have a valid and set up API key please enter it in', 'harizma' ),
					admin_url( 'options-general.php?page=arts-setting-gmap' ),
					esc_html__( 'in WordPress admin panel.', 'harizma' ),
					esc_html__( 'and return back here.', 'harizma' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				'condition'       => array(
					'is_key' => false,
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'marker_content',
			array(
				'label'       => esc_html__( 'Content Box', 'harizma' ),
				'description' => esc_html__( 'That content will appear in a small window on marker click. You can place a helpful information here (e.g. company address).', 'harizma' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => '',
			)
		);

		$repeater->add_control(
			'marker_lat',
			array(
				'label'   => esc_html__( 'Latitude', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '40.6700',
			)
		);

		$repeater->add_control(
			'marker_lon',
			array(
				'label'   => esc_html__( 'Longitude', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '-73.9400',
			)
		);

		$repeater->add_control(
			'marker_icon',
			array(
				'label'       => esc_html__( 'Icon', 'harizma' ),
				'description' => esc_html__( 'Upload a PNG image of a nice map pin.', 'harizma' ),
				'type'        => Controls_Manager::MEDIA,
			)
		);

		$repeater->add_control(
			'marker_icon_size',
			array(
				'label'     => esc_html__( 'Image Size', 'harizma' ),
				'type'      => Controls_Manager::IMAGE_DIMENSIONS,
				'default'   => array(
					'width'  => '',
					'height' => '',
				),
				'condition' => array(
					'marker_icon!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'markers',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ marker_content }}}',
				'prevent_empty' => true,
				'condition'     => array(
					'is_key' => true,
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Form
		 */
		$this->start_controls_section(
			'form_section',
			array(
				'label' => esc_html__( 'Contact Form', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'shortcode',
			array(
				'label'       => esc_html__( 'Enter your shortcode', 'harizma' ),
				'description' => sprintf(
					'%1$s <a href="%2$s" target="_blank">%3$s</a> %3$s',
					esc_html__( 'You can get your contact form shorcode from', 'harizma' ),
					admin_url( 'admin.php?page=wpcf7' ),
					esc_html__( 'Contact Form 7 menu', 'harizma' ),
					esc_html__( 'in admin panel', 'harizma' )
				),
				'type'        => Controls_Manager::TEXTAREA,
				'render_type' => 'template',
				'placeholder' => 'Example: [contact-form-7 id="4" title="Harizma Contact Form Inline"]',
				'default'     => '',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Contacts
		 */
		$this->start_controls_section(
			'contacts_section',
			array(
				'label' => esc_html__( 'Contacts', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'contact',
			array(
				'label'   => esc_html__( 'Contact Info', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'hello@example.com', 'harizma' ),
			)
		);

		$repeater->add_control(
			'info',
			array(
				'label'   => esc_html__( 'Additional Info', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Send us a message', 'harizma' ),
			)
		);

		$this->add_control(
			'contacts',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ contact }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Style
		 */
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'harizma' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'map_zoom',
			array(
				'label'       => esc_html__( 'Zoom Level', 'harizma' ),
				'description' => esc_html__( 'Applicable if there is only a single marker on the map', 'harizma' ),
				'type'        => Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 1,
						'max' => 20,
					),
				),
				'default'     => array(
					'unit' => 'px',
					'size' => 8,
				),
				'condition'   => array(
					'is_key' => true,
				),
			)
		);

		$this->add_control(
			'snazzy_styles',
			array(
				'label'       => esc_html__( 'Snazzy Maps Styles', 'harizma' ),
				'type'        => Controls_Manager::TEXTAREA,
				'description' => sprintf(
					'%1$s <a href="https://snazzymaps.com/explore" target="_blank">%2$s</a> %3$s',
					esc_html__( 'You can preview and generate custom map styles on', 'harizma' ),
					esc_html__( 'Snazzy Maps.', 'harizma' ),
					esc_html__( 'Just copy-paste JavaScript style array in this field.', 'harizma' )
				),
				'default'     => '[{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":21}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":16}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":17}]}]',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings  = $this->get_settings_for_display();
		$shortcode = do_shortcode( shortcode_unautop( $settings['shortcode'] ) );

		$this->add_render_attribute(
			'gmap',
			array(
				'class'                   => 'gmap',
				'data-gmap-zoom'          => is_array( $settings['map_zoom'] ) ? $settings['map_zoom']['size'] : 8,
				'data-gmap-snazzy-styles' => preg_replace( '^\n|\r|\s+|\s+^', '', $settings['snazzy_styles'] ),
			)
		);
		?>
		<div class="section-map__content">
			<div class="section-map__wrapper-map">
				<div <?php echo $this->get_render_attribute_string( 'gmap' ); ?>>
					<div class="gmap__container"></div>
					<?php if ( $settings['markers'] ) : ?>
						<?php foreach ( $settings['markers'] as $index => $item ) : ?>
							<?php
								$rowKey = $this->get_repeater_setting_key( 'marker', 'markers', $index );
								$this->add_render_attribute(
									$rowKey,
									array(
										'class'           => 'gmap__marker d-none',
										'data-marker-lat' => $item['marker_lat'],
										'data-marker-lon' => $item['marker_lon'],
										'data-marker-content' => $item['marker_content'],
										'data-marker-img' => $item['marker_icon']['url'],
										'data-marker-width' => $item['marker_icon_size']['width'],
										'data-marker-height' => $item['marker_icon_size']['height'],
									)
								);
							?>
							<div <?php echo $this->get_render_attribute_string( $rowKey ); ?>></div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
			<!-- - google map -->
			<?php if ( ! empty( $shortcode ) ) : ?>
				<div class="section-map__wrapper-form">
					<div class="form">
						<?php echo $shortcode; ?>
					</div>
				</div>
				<!-- - floating contact form -->
			<?php endif; ?>
			<?php if ( ! empty( $settings['contacts'] ) ) : ?>
				<div class="section-map__wrapper-info color-white">
					<div class="figure-contact">
						<?php foreach ( $settings['contacts'] as $index => $item ) : ?>
							<?php
								$keyContact = $this->get_repeater_setting_key( 'contact', 'contacts', $index );
								$keyInfo    = $this->get_repeater_setting_key( 'info', 'contacts', $index );
								$this->add_inline_editing_attributes( $keyContact );
								$this->add_inline_editing_attributes( $keyInfo );
							?>
							<div class="figure-contact__item">
								<?php if ( ! empty( $item['contact'] ) ) : ?>
									<div class="figure-contact__property"><span <?php echo $this->get_render_attribute_string( $keyContact ); ?>><?php echo $item['contact']; ?></span></div>
								<?php endif; ?>
								<?php if ( ! empty( $item['info'] ) ) : ?>
									<div class="figure-contact__value"><span <?php echo $this->get_render_attribute_string( $keyInfo ); ?>><?php echo $item['info']; ?></span></div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<!-- - company information -->
			<?php endif; ?>
		</div>
		<?php
	}
}
