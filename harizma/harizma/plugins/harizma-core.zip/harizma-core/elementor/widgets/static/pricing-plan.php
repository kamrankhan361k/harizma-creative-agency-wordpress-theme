<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Pricing_Plan extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-pricing-plan';
	}

	public function get_title() {
		return esc_html__( 'Pricing Plan', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(
				array(
					'field'       => 'pricing_heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_value',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Amount Value', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_label',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Amount Label', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_symbol_before',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Symbol Before', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_symbol_after',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Symbol After', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_title',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Link', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'featured_label',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Featured Label', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
			'integration-class' => 'WPML_Elementor_Harizma_Widget_Pricing_Plan',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'pricing_heading',
			array(
				'label'       => esc_html__( 'Heading', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Basic', 'harizma' ),
			)
		);

		$this->add_control(
			'amount_heading',
			array(
				'label'     => esc_html__( 'Amount', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'amount_value',
			array(
				'label'       => esc_html__( 'Value', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '52',
			)
		);

		$this->add_control(
			'amount_label',
			array(
				'label'       => esc_html__( 'Label', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'per month', 'harizma' ),
			)
		);

		$this->add_control(
			'amount_symbol_before',
			array(
				'label'   => esc_html__( 'Symbol Before', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '$',
			)
		);

		$this->add_control(
			'amount_symbol_after',
			array(
				'label'   => esc_html__( 'Sign After Amount', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'features_heading',
			array(
				'label'     => esc_html__( 'Features', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'feature',
			array(
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Amazing feature', 'harizma' ),
			)
		);

		$repeater->add_control(
			'feature_included',
			array(
				'label'        => esc_html__( 'Included', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'features',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ feature }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Button', 'harizma' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'harizma' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'harizma' ),
					'button_solid'    => esc_html__( 'Solid', 'harizma' ),
				),
				'default'     => 'button_bordered',
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_accent' => esc_html__( 'Accent', 'harizma' ),
					'button_dark'   => esc_html__( 'Dark', 'harizma' ),
					'button_light'  => esc_html__( 'Light', 'harizma' ),
					'button_black'  => esc_html__( 'Black', 'harizma' ),
					'button_white'  => esc_html__( 'White', 'harizma' ),
				),
				'default'     => 'button_accent',
			)
		);

		$this->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'harizma' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'is_pricing_bordered',
			array(
				'label'        => esc_html__( 'Enable Bordered Style', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'figure-pricing_bordered',
			)
		);

		$this->add_control(
			'is_pricing_transparent',
			array(
				'label'        => esc_html__( 'Enable Transparent Style', 'harizma' ),
				'description'  => esc_html__( 'Use this with dark section background.', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'figure-pricing_transparent',
				'default'      => '',
			)
		);

		$this->add_control(
			'is_pricing_centered',
			array(
				'label'        => esc_html__( 'Enable Center Alignment', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'text-center',
			)
		);

		$this->add_control(
			'is_height_equal',
			array(
				'label'       => esc_html__( 'Set height to the tallest pricing table.', 'harizma' ),
				'description' => esc_html__( 'Useful if you have the pricing tables of different heights. Applicable for the current row in layout.', 'harizma' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'selectors'   => array(
					'{{WRAPPER}}' => 'height: 100%;',
					'{{WRAPPER}} .elementor-widget-container' => 'height: 100%;',
				),
			)
		);

		$this->add_control(
			'featured_heading',
			array(
				'label'     => esc_html__( 'Featured', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'is_pricing_featured',
			array(
				'label'        => esc_html__( 'Enable Featured Highlight', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'figure-pricing_featured',
			)
		);

		$this->add_control(
			'featured_label',
			array(
				'label'     => esc_html__( 'Featured Label', 'harizma' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Most Popular', 'harizma' ),
				'condition' => array(
					'is_pricing_featured!' => '',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'pricing_heading' );
		$this->add_inline_editing_attributes( 'featured_label' );
		$this->add_inline_editing_attributes( 'amount_value' );
		$this->add_inline_editing_attributes( 'amount_label' );
		$this->add_inline_editing_attributes( 'amount_symbol_before' );
		$this->add_inline_editing_attributes( 'amount_symbol_after' );
		$this->add_inline_editing_attributes( 'button_title' );

		$this->add_render_attribute(
			'pricing',
			array(
				'class' => array(
					'figure-pricing',
					$settings['is_pricing_featured'],
					$settings['is_pricing_bordered'],
					$settings['is_pricing_transparent'],
					$settings['is_pricing_centered'],
				),
			)
		);
		?>
		<div <?php echo $this->get_render_attribute_string( 'pricing' ); ?>>
			<?php if ( ! empty( $settings['is_pricing_featured'] ) && ! empty( $settings['featured_label'] ) ) : ?>
				<div class="figure-pricing__feature-label">
					<span <?php echo $this->get_render_attribute_string( 'featured_label' ); ?>><?php echo $settings['featured_label']; ?></span>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['pricing_heading'] ) ) : ?>
				<div class="figure-pricing__header">
					<h5 <?php echo $this->get_render_attribute_string( 'pricing_heading' ); ?>><?php echo $settings['pricing_heading']; ?></h5>
				</div>
				<!-- - header-->
			<?php endif; ?>
			<?php if ( ! empty( $settings['amount_value'] ) || ! empty( $settings['amount_label'] ) ) : ?>
				<div class="figure-pricing__cost">
					<?php if ( ! empty( $settings['amount_symbol_before'] ) ) : ?>
						<div class="figure-pricing__cost-sign figure-pricing__cost-sign_before">
							<span <?php echo $this->get_render_attribute_string( 'amount_symbol_before' ); ?>><?php echo $settings['amount_symbol_before']; ?></span>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['amount_value'] ) ) : ?>
						<div class="figure-pricing__amount">
							<span <?php echo $this->get_render_attribute_string( 'amount_value' ); ?>><?php echo $settings['amount_value']; ?></span>
							<?php if ( ! empty( $settings['amount_label'] ) ) : ?>
								<div class="figure-pricing__label">
									<span <?php echo $this->get_render_attribute_string( 'amount_label' ); ?>><?php echo $settings['amount_label']; ?></span>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['amount_symbol_after'] ) ) : ?>
						<div class="figure-pricing__cost-sign figure-pricing__cost-sign_after">
							<span <?php echo $this->get_render_attribute_string( 'amount_symbol_after' ); ?>><?php echo $settings['amount_symbol_after']; ?></span>
						</div>
					<?php endif; ?>
				</div>
				<!-- - cost-->
			<?php endif; ?>
			<div class="figure-pricing__divider"></div>
			<!-- - divider-->
			<?php if ( ! empty( $settings['features'] ) ) : ?>
				<ul class="figure-pricing__features">
					<?php foreach ( $settings['features'] as $index => $item ) : ?>
						<?php
							$rowKey = $this->get_repeater_setting_key( 'feature', 'features', $index );
							$this->add_inline_editing_attributes( $rowKey );

							$this->add_render_attribute(
								'included' . $rowKey,
								array(
									'class' => 'figure-pricing__feature',
								)
							);

						if ( $item['feature_included'] ) {

							$this->add_render_attribute(
								'included' . $rowKey,
								array(
									'class' => 'figure-pricing__feature_yes',
								)
							);

						} else {

							$this->add_render_attribute(
								'included' . $rowKey,
								array(
									'class' => 'figure-pricing__feature_no',
								)
							);

						}
						?>
						<li <?php echo $this->get_render_attribute_string( 'included' . $rowKey ); ?>>
							<span <?php echo $this->get_render_attribute_string( $rowKey ); ?>><?php echo $item['feature']; ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
				<!-- - features-->
			<?php endif; ?>
			<?php if ( ! empty( $settings['button_title'] ) ) : ?>
				<div class="figure-pricing__wrapper-button">
					<?php
						$this->add_render_attribute(
							'button',
							array(
								'class' => array( 'button', 'button_fullwidth', $settings['button_style'], $settings['button_color'], $settings['button_shadow'] ),
								'href'  => $settings['button_link']['url'],
							)
						);

					if ( $settings['button_link']['is_external'] ) {
						$this->add_render_attribute( 'button', 'target', '_blank' );
					}

					if ( $settings['button_link']['nofollow'] ) {
						$this->add_render_attribute( 'button', 'rel', 'nofollow' );
					}
					?>
					<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( 'button_title' ); ?>><?php echo $settings['button_title']; ?></span></a>
				</div>
				<!-- - button-->
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'pricing_heading' );
		view.addInlineEditingAttributes( 'featured_label' );
		view.addInlineEditingAttributes( 'amount_value' );
		view.addInlineEditingAttributes( 'amount_label' );
		view.addInlineEditingAttributes( 'amount_symbol_before' );
		view.addInlineEditingAttributes( 'amount_symbol_after' );
		view.addInlineEditingAttributes( 'button_title' );

		view.addRenderAttribute(
			'pricing', {
				'class': [
					'figure-pricing',
					settings.is_pricing_featured,
					settings.is_pricing_bordered,
					settings.is_pricing_transparent,
					settings.is_pricing_centered,
				]
			}
		);
		#>
		<div {{{ view.getRenderAttributeString( 'pricing' ) }}}>
			<# if ( settings.is_pricing_featured && settings.featured_label ) { #>
				<div class="figure-pricing__feature-label">
					<span {{{ view.getRenderAttributeString( 'featured_label' ) }}}>{{{ settings.featured_label }}}</span>
				</div>
			<# } #>
			<# if ( settings.pricing_heading ) { #>
				<div class="figure-pricing__header">
					<h5 {{{ view.getRenderAttributeString( 'pricing_heading' ) }}}>{{{ settings.pricing_heading }}}</h5>
				</div>
				<!-- - header-->
			<# } #>
			<# if ( settings.amount_value || settings.amount_label ) { #>
				<div class="figure-pricing__cost">
					<# if ( settings.amount_symbol_before ) { #>
						<div class="figure-pricing__cost-sign figure-pricing__cost-sign_before">
							<span {{{ view.getRenderAttributeString( 'amount_symbol_before' ) }}}>{{{ settings.amount_symbol_before }}}</span>
						</div>
					<# } #>
					<# if ( settings.amount_value ) { #>
						<div class="figure-pricing__amount">
							<span {{{ view.getRenderAttributeString( 'amount_value' ) }}}>{{{ settings.amount_value }}}</span>
							<# if ( settings.amount_label ) { #>
								<div class="figure-pricing__label">
									<span {{{ view.getRenderAttributeString( 'amount_label' ) }}}>{{{ settings.amount_label }}}</span>
								</div>
							<# } #>
						</div>
					<# } #>
					<# if ( settings.amount_symbol_after ) { #>
						<div class="figure-pricing__cost-sign figure-pricing__cost-sign_after">
							<span {{{ view.getRenderAttributeString( 'amount_symbol_after' ) }}}>{{{ settings.amount_symbol_after }}}</span>
						</div>
					<# } #>
				</div>
				<!-- - cost-->
			<# } #>
			<div class="figure-pricing__divider"></div>
			<!-- - divider-->
			<# if ( settings.features.length ) { #>
				<ul class="figure-pricing__features">
					<# _.each( settings.features, function(item, index) { #>
						<#
							var rowKey = view.getRepeaterSettingKey( 'feature', 'features', index );
							view.addInlineEditingAttributes( rowKey );

							view.addRenderAttribute('included' + rowKey, {
								'class': 'figure-pricing__feature'
							});

							if ( item.feature_included ) {

								view.addRenderAttribute('included' + rowKey, {
									'class': 'figure-pricing__feature_yes'
								});

							} else {

								view.addRenderAttribute('included' + rowKey, {
									'class': 'figure-pricing__feature_no'
								});

							}
						#>
						<li {{{ view.getRenderAttributeString( 'included' + rowKey ) }}}>
							<span {{{ view.getRenderAttributeString( rowKey ) }}}>{{{ item.feature }}}</span>
						</li>
					<# }); #>
				</ul>
				<!-- - features-->
			<# } #>
			<# if ( settings.button_title ) { #>
				<div class="figure-pricing__wrapper-button">
					<#
					view.addRenderAttribute(
							'button', {
								'class': [ 'button', 'button_fullwidth', settings.button_style, settings.button_color, settings.button_shadow ],
								'href': settings.button_link.url,
							}
						);

					if ( settings.button_link.is_external ) {
						view.addRenderAttribute( 'button', 'target', '_blank' );
					}

					if ( settings.button_link.nofollow ) {
						view.addRenderAttribute( 'button', 'rel', 'nofollow' );
					}
					#>
					<a {{{ view.getRenderAttributeString( 'button' ) }}}><span {{{ view.getRenderAttributeString( 'button_title' ) }}}>{{{ settings.button_title }}}</span></a>
				</div>
				<!-- - button-->
			<# } #>
		</div>
		<?php
	}
}
