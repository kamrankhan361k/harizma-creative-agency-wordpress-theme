<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Slider_Intro extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-slider-intro';
	}

	public function get_title() {
		return esc_html__( 'Slider Intro', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(
				array(
					'field'       => 'sd_label',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Scroll Down Label', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
			'integration-class' => 'WPML_Elementor_Harizma_Widget_Slider_Intro',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Slides', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'harizma' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Heading...', 'harizma' ),
			)
		);

		$repeater->add_control(
			'description',
			array(
				'label'   => esc_html__( 'Description', 'harizma' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Description...', 'harizma' ),
			)
		);

		$repeater->add_control(
			'button_heading',
			array(
				'label'     => esc_html__( 'Button', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$repeater->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Button', 'harizma' ),
			)
		);

		$repeater->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'harizma' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$repeater->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'harizma' ),
					'button_solid'    => esc_html__( 'Solid', 'harizma' ),
				),
				'default'     => 'button_solid',
			)
		);

		$repeater->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_accent' => esc_html__( 'Accent', 'harizma' ),
					'button_dark'   => esc_html__( 'Dark', 'harizma' ),
					'button_light'  => esc_html__( 'Light', 'harizma' ),
					'button_black'  => esc_html__( 'Black', 'harizma' ),
					'button_white'  => esc_html__( 'White', 'harizma' ),
				),
				'default'     => 'button_white',
			)
		);

		$repeater->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
			)
		);

		$repeater->add_control(
			'image',
			array(
				'label'     => esc_html__( 'Background Image', 'harizma' ),
				'type'      => Controls_Manager::MEDIA,
				'separator' => 'before',
				'default'   => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'slides',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ heading }}}',
				'prevent_empty' => true,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			array(
				'label' => esc_html__( 'Slider', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_dots',
			array(
				'label'   => esc_html__( 'Enable Dots', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => esc_html__( 'Autoplay', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'harizma' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 1200,
				),
			)
		);

		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'harizma' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => array(
					'ltr' => array(
						'title' => esc_html__( 'Left to Right', 'harizma' ),
						'icon'  => 'eicon-chevron-double-right',
					),
					'rtl' => array(
						'title' => esc_html__( 'Right to Left', 'harizma' ),
						'icon'  => 'eicon-chevron-double-left',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'sd_section',
			array(
				'label' => esc_html__( 'Scroll Down', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_sd',
			array(
				'label'   => esc_html__( 'Show Pointer', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'sd_label',
			array(
				'label'     => esc_html__( 'Label', 'harizma' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Scroll', 'harizma' ),
				'condition' => array(
					'enable_sd' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings   = $this->get_settings_for_display();
		$num_slides = count( $settings['slides'] );

		$this->add_inline_editing_attributes( 'sd_label' );

		$this->add_render_attribute(
			'swiper',
			array(
				'class'      => array( 'slider', 'slider-intro-content', 'swiper', 'swiper-container', 'js-slider-intro-content' ),
				'data-speed' => is_array( $settings['speed'] ) ? $settings['speed']['size'] : 0,
				'dir'        => $settings['direction'],
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => is_array( $settings['autoplay_delay'] ) ? $settings['autoplay_delay']['size'] : 0,
				)
			);
		}
		?>
		<div class="section section-intro section-fullheight color-white">
			<div class="section-fullheight__inner">
				<div class="container-fluid section-intro__wrapper-content">
					<div class="row">
						<div class="col-lg-5">
							<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
								<div class="swiper-wrapper">
									<?php if ( ! empty( $settings['slides'] ) ) : ?>
										<?php foreach ( $settings['slides'] as $index => $item ) : ?>
											<?php
												$keyHeading     = $this->get_repeater_setting_key( 'heading', 'slides', $index );
												$keyDescription = $this->get_repeater_setting_key( 'description', 'slides', $index );
												$this->add_inline_editing_attributes( $keyHeading );
												$this->add_inline_editing_attributes( $keyDescription );
											?>
											<div class="swiper-slide">
												<?php if ( ! empty( $item['heading'] ) ) : ?>
													<h1 <?php echo $this->get_render_attribute_string( $keyHeading ); ?>><?php echo $item['heading']; ?></h1>
												<?php endif; ?>
												<?php if ( ! empty( $item['description'] ) ) : ?>
													<p <?php echo $this->get_render_attribute_string( $keyDescription ); ?>><?php echo $item['description']; ?></p>
												<?php endif; ?>
												<?php if ( ! empty( $item['button_title'] ) ) : ?>
													<div class="slider-intro-content__wrapper-button">
														<?php

															$keyButton = $this->get_repeater_setting_key( 'button_title', 'slides', $index );
															$this->add_inline_editing_attributes( $keyButton );

															$this->add_render_attribute(
																'button',
																array(
																	'class' => array( 'button', $item['button_style'], $item['button_color'], $item['button_shadow'] ),
																	'href'  => $item['button_link']['url'],
																),
																true,
																true
															);

														if ( $item['button_link']['is_external'] ) {
															$this->add_render_attribute( 'button', 'target', '_blank', true, true );
														}

														if ( $item['button_link']['nofollow'] ) {
															$this->add_render_attribute( 'button', 'rel', 'nofollow', true, true );
														}

														?>
														<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( $keyButton ); ?>><?php echo $item['button_title']; ?></span></a>
													</div>
												<?php endif; ?>
											</div>
										<?php endforeach; ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- - slider intro content -->
				<?php if ( ! empty( $settings['slides'] ) ) : ?>
					<div class="section-intro__wrapper-backgrounds bg-light">
						<div class="slider slider-intro-backgrounds swiper swiper-container js-slider-intro-backgrounds">
							<div class="swiper-wrapper">
								<?php if ( $num_slides === 1 ) : ?>
									<div class="swiper-slide">
										<img class="of-cover" src="<?php echo esc_url( $settings['slides'][0]['image']['url'] ); ?>" alt=""/>
									</div>									
								<?php else : ?>
									<?php foreach ( $settings['slides'] as $index => $item ) : ?>
										<div class="swiper-slide">
											<img class="of-cover swiper-lazy" data-src="<?php echo esc_url( $item['image']['url'] ); ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt=""/>
										</div>
									<?php endforeach; ?>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<!-- - slider backgrounds-->
				<?php endif; ?>
				<?php if ( $settings['enable_sd'] ) : ?>
					<div class="section-intro__wrapper-sd">
						<div class="scroll-down js-scroll-down">
							<?php if ( ! empty( $settings['sd_label'] ) ) : ?>
								<div class="scroll-down__label"><span <?php echo $this->get_render_attribute_string( 'sd_label' ); ?>><?php echo $settings['sd_label']; ?></span></div>
							<?php endif; ?>
							<div class="scroll-down__icon"><img src="<?php echo get_theme_file_uri( 'img/general/triangle-down.svg' ); ?>" alt="<?php esc_attr_e( 'Scroll down', 'harizma' ); ?>"/></div>
						</div>
					</div>
					<!-- - scroll down-->
				<?php endif; ?>
				<?php if ( $num_slides > 1 && $settings['enable_dots'] ) : ?>
					<div class="slider-intro-content__wrapper-slider-nav">
						<div class="slider-nav js-slider-intro-content__nav">
							<div class="slider-nav__dot slider-nav__dot_active"></div>
							<div class="slider-nav__dot"></div>
							<div class="slider-nav__dot"></div>
						</div>
					</div>
					<!-- - slider dots -->
				<?php endif; ?>
			</div>
			<!-- decor elements -->
			<div class="section-intro__diagonal-curtain-1"></div>
			<div class="section-intro__diagonal-curtain-2"></div>
			<div class="section-intro__diagonal-line-1"></div>
			<div class="section-intro__diagonal-line-2"></div>
			<!-- - decor elements -->
			<div class="overlay overlay_black d-lg-none"></div>
	  </div>
		<?php
	}

	protected function content_template() {
		?>
		<#
		var num_slides = settings.slides.length;

		view.addInlineEditingAttributes( 'sd_label' );

		view.addRenderAttribute(
			'swiper', {
				'class': [ 'slider-intro-content', 'swiper', 'swiper-container', 'js-slider-intro-content' ],
				'data-speed': settings.speed.size,
				'dir': settings.direction,
			}
		);

		if ( settings.enable_autoplay ) {
			view.addRenderAttribute(
				'swiper', {
					'data-autoplay-enabled': 'true',
					'data-autoplay-delay': settings.autoplay_delay.size,
				}
			);
		}
		#>
		<div class="section section-intro section-fullheight color-white">
			<div class="section-fullheight__inner">
				<div class="container-fluid section-intro__wrapper-content">
					<div class="row">
						<div class="col-lg-5">
							<div {{{ view.getRenderAttributeString( 'swiper' ) }}}>
								<div class="swiper-wrapper">
									<# if ( settings.slides.length ) { #>
										<# _.each( settings.slides, function(item, index) { #>
											<#
												var keyHeading = view.getRepeaterSettingKey( 'heading', 'slides', index );
												var keyDescription = view.getRepeaterSettingKey( 'description', 'slides', index );
												view.addInlineEditingAttributes( keyHeading );
												view.addInlineEditingAttributes( keyDescription );
											#>
											<div class="swiper-slide">
												<# if ( item.heading ) { #>
													<h1 {{{ view.getRenderAttributeString( keyHeading ) }}}>{{{ item.heading }}}</h1>
												<# } #>
												<# if ( item.description ) { #>
													<p {{{ view.getRenderAttributeString( keyDescription ) }}}>{{{ item.description }}}</p>
												<# } #>
												<# if ( item.button_title ) { #>
													<div class="slider-intro-content__wrapper-button">
														<#

															var keyButton = view.getRepeaterSettingKey( 'button_title', 'slides', index );
															view.addInlineEditingAttributes( keyButton );

															view.addRenderAttribute(
																'button', {
																	'class': [ 'button', item.button_style, item.button_color, item.button_shadow ],
																	'href': item.button_link.url,
																}
															);

															if ( item.button_link.is_external ) {
																view.addRenderAttribute( 'button', 'target', '_blank' );
															}

															if ( item.button_link.nofollow ) {
																view.addRenderAttribute( 'button', 'rel', 'nofollow' );
															}

														#>
														<a {{{ view.getRenderAttributeString( 'button' ) }}}><span {{{ view.getRenderAttributeString( 'button_title' ) }}}>{{{ item.button_title }}}</span></a>
													</div>
												<# } #>
											</div>
										<# }); #>
									<# } #>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- - slider intro content -->
				<# if ( settings.slides ) { #>
					<div class="section-intro__wrapper-backgrounds bg-light">
						<div class="slider slider-intro-backgrounds swiper swiper-container js-slider-intro-backgrounds">
							<div class="swiper-wrapper">
								<# if ( num_slides === 1 ) { #>
									<div class="swiper-slide">
										<img class="of-cover" src="{{{ settings.slides[0].image.url }}}" alt=""/>
									</div>
								<# } else { #>
									<# _.each( settings.slides, function(item, index) { #>
										<div class="swiper-slide">
											<img class="of-cover swiper-lazy" data-src="{{{ item.image.url }}}" src="img/general/lazy-placeholder.png" alt=""/>
										</div>
									<# }); #>
								<# } #>
							</div>
						</div>
					</div>
					<!-- - slider backgrounds-->
				<# } #>
				<# if ( settings.enable_sd ) { #>
					<div class="section-intro__wrapper-sd">
						<div class="scroll-down js-scroll-down">
							<# if ( settings.sd_label ) { #>
								<div class="scroll-down__label"><span {{{ view.getRenderAttributeString( 'sd_label' ) }}}>{{{ settings.sd_label }}}</span></div>
							<# } #>
							<div class="scroll-down__icon"><img src="<?php echo get_theme_file_uri( 'img/general/triangle-down.svg' ); ?>" alt="<?php esc_attr_e( 'Scroll down', 'harizma' ); ?>"/></div>
						</div>
					</div>
					<!-- - scroll down-->
				<# } #>
				<# if ( num_slides > 1 && settings.enable_dots ) { #>
					<div class="slider-intro-content__wrapper-slider-nav">
						<div class="slider-nav js-slider-intro-content__nav">
							<div class="slider-nav__dot slider-nav__dot_active"></div>
							<div class="slider-nav__dot"></div>
							<div class="slider-nav__dot"></div>
						</div>
					</div>
					<!-- - slider dots -->
				<# } #>
			</div>
			<!-- decor elements -->
			<div class="section-intro__diagonal-curtain-1"></div>
			<div class="section-intro__diagonal-curtain-2"></div>
			<div class="section-intro__diagonal-line-1"></div>
			<div class="section-intro__diagonal-line-2"></div>
			<!-- - decor elements -->
			<div class="overlay overlay_black d-lg-none"></div>
		</div>
		<?php
	}
}
