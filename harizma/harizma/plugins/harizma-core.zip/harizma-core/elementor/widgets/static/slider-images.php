<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Slider_Images extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-slider-images';
	}

	public function get_title() {
		return esc_html__( 'Slider Images', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Images', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'images_gallery',
			array(
				'type'    => Controls_Manager::GALLERY,
				'default' => array(),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Slider
		 */
		$this->start_controls_section(
			'slider_section',
			array(
				'label' => esc_html__( 'Slider', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_responsive_control(
			'slides_per_view',
			array(
				'label'           => esc_html__( 'Slides Per Screen', 'harizma' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'number' => array(
						'min'  => 1,
						'max'  => 4,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 1.75,
					'unit' => 'number',
				),
				'tablet_default'  => array(
					'size' => 1.33,
					'unit' => 'number',
				),
				'mobile_default'  => array(
					'size' => 1.2,
					'unit' => 'number',
				),
			)
		);

		$this->add_responsive_control(
			'centered_slides',
			array(
				'label'           => esc_html__( 'Centered Slides', 'harizma' ),
				'label_block'     => true,
				'type'            => Controls_Manager::SWITCHER,
				'desktop_default' => true,
				'tablet_default'  => true,
				'mobile_default'  => true,
			)
		);

		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => esc_html__( 'Space Between Slides', 'harizma' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 160,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 30,
					'unit' => 'px',
				),
				'tablet_default'  => array(
					'size' => 15,
					'unit' => 'px',
				),
				'mobile_default'  => array(
					'size' => 15,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'enable_navigation',
			array(
				'label'   => esc_html__( 'Enable Navigation Arrows', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_dots',
			array(
				'label'   => esc_html__( 'Enable Dots', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => esc_html__( 'Autoplay', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'harizma' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'harizma' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 1200,
				),
			)
		);

		$this->add_control(
			'direction',
			array(
				'label'   => esc_html__( 'Direction', 'harizma' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'ltr',
				'options' => array(
					'ltr' => array(
						'title' => esc_html__( 'Left to Right', 'harizma' ),
						'icon'  => 'eicon-chevron-double-right',
					),
					'rtl' => array(
						'title' => esc_html__( 'Right to Left', 'harizma' ),
						'icon'  => 'eicon-chevron-double-left',
					),
				),
				'toggle'  => false,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			'swiper',
			array(
				'class'                       => array( 'swiper', 'swiper-container', 'slider', 'slider-images', 'js-slider-images' ),
				'data-speed'                  => is_array( $settings['speed'] ) ? $settings['speed']['size'] : 0,
				'dir'                         => $settings['direction'],
				'data-slides-per-view'        => is_array( $settings['slides_per_view'] ) ? $settings['slides_per_view']['size'] : 0,
				'data-slides-per-view-tablet' => is_array( $settings['slides_per_view_tablet'] ) ? $settings['slides_per_view_tablet']['size'] : 0,
				'data-slides-per-view-mobile' => is_array( $settings['slides_per_view_mobile'] ) ? $settings['slides_per_view_mobile']['size'] : 0,
				'data-space-between'          => is_array( $settings['space_between'] ) ? $settings['space_between']['size'] : 0,
				'data-space-between-tablet'   => is_array( $settings['space_between_tablet'] ) ? $settings['space_between_tablet']['size'] : 0,
				'data-space-between-mobile'   => is_array( $settings['space_between_mobile'] ) ? $settings['space_between_mobile']['size'] : 0,
				'data-centered-slides'        => $settings['centered_slides'],
				'data-centered-slides-tablet' => $settings['centered_slides_tablet'],
				'data-centered-slides-mobile' => $settings['centered_slides_mobile'],
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => is_array( $settings['autoplay_delay'] ) ? $settings['autoplay_delay']['size'] : 0,
				)
			);
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
			<div class="swiper-wrapper">
				<?php if ( ! empty( $settings['images_gallery'] ) ) : ?>
					<?php foreach ( $settings['images_gallery'] as $image ) : ?>
						<div class="swiper-slide">
							<?php
								$src = wp_get_attachment_image_src( $image['id'], 'full' );
							?>
							<img class="swiper-lazy" data-src="<?php echo $src[0]; ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" width="<?php echo $src[1]; ?>"  height="<?php echo $src[2]; ?>" alt="" data-swiper-parallax="true" data-swiper-parallax-opacity="0.5">
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
			<?php if ( $settings['enable_dots'] ) : ?>
				<div class="slider-images__wrapper-slider-nav">
					<div class="slider-nav js-slider-images__nav">
						<div class="slider-nav__dot slider-nav__dot_active"></div>
						<div class="slider-nav__dot"></div>
						<div class="slider-nav__dot"></div>
					</div>
				</div>
				<!-- - slider dots -->
			<?php endif; ?>
			<?php if ( $settings['enable_navigation'] ) : ?>
				<div class="slider__prev slider-images__prev js-slider-images__prev"></div>
				<div class="slider__next slider-images__next js-slider-images__next"></div>
				<!-- - slider arrows -->
			<?php endif; ?>
		</div>
		<?php
	}
}
