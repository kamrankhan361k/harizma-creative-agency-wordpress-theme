<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Feature extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-feature';
	}

	public function get_title() {
		return esc_html__( 'Feature', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'description',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Description', 'harizma' ) ),
					'editor_type' => 'AREA',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'icon',
			array(
				'label' => esc_html__( 'Icon', 'harizma' ),
				'type'  => Controls_Manager::ICON,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Feature name...', 'harizma' ),
			)
		);

		$this->add_control(
			'description',
			array(
				'label'       => esc_html__( 'Description', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description...', 'harizma' ),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'description' );
		?>

		<div class="figure-feature">
			<?php if ( ! empty( $settings['icon'] ) ) : ?>
				<div class="figure-feature__icon <?php echo $settings['icon']; ?>"></div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['heading'] ) || ! empty( $settings['description'] ) ) : ?>
				<div class="figure-feature__content">
					<?php if ( ! empty( $settings['heading'] ) ) : ?>
						<h3 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h3>
					<?php endif; ?>
					<?php if ( ! empty( $settings['description'] ) ) : ?>
						<p <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo $settings['description']; ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php
	}

	protected function content_template() {
		?>

		<#
			view.addInlineEditingAttributes( 'heading' );
			view.addInlineEditingAttributes( 'description' );
		#>

		<div class="figure-feature">
			<# if ( settings.icon ) { #>
				<div class="figure-feature__icon {{{ settings.icon }}}"></div>
			<# } #>
			<# if ( settings.heading || settings.description ) { #>
				<div class="figure-feature__content">
					<# if ( settings.heading ) { #>
						<h3 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h3>
					<# } #>
					<# if ( settings.description ) { #>
						<p {{{ view.getRenderAttributeString( 'description' ) }}}>{{{ settings.description }}}</p>
					<# } #>
				</div>
			<# } #>
		</div>

		<?php
	}
}
