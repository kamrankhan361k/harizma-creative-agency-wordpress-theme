<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Project_Properties extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-project-properties';
	}

	public function get_title() {
		return esc_html__( 'Project Properties', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(
				array(
					'field'       => 'button_title',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Title', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Link', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
			'integration-class' => 'WPML_Elementor_Harizma_Widget_Project_Properties',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'option',
			array(
				'label'       => esc_html__( 'Option', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$repeater->add_control(
			'value',
			array(
				'label'       => esc_html__( 'Value', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'properties',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ option || value }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_button',
			array(
				'label'   => esc_html__( 'Show Button', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Button', 'harizma' ),
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'harizma' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
				'condition'     => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'harizma' ),
					'button_solid'    => esc_html__( 'Solid', 'harizma' ),
				),
				'default'     => 'button_solid',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_accent' => esc_html__( 'Accent', 'harizma' ),
					'button_dark'   => esc_html__( 'Dark', 'harizma' ),
					'button_light'  => esc_html__( 'Light', 'harizma' ),
					'button_black'  => esc_html__( 'Black', 'harizma' ),
					'button_white'  => esc_html__( 'White', 'harizma' ),
				),
				'default'     => 'button_accent',
				'condition'   => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'harizma' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
				'condition'    => array(
					'enable_button' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'button_title' );
		?>
		<div class="d-flex justify-content-between align-items-center flex-wrap">
			<?php if ( ! empty( $settings['properties'] ) ) : ?>
				<div class="col-auto">
					<ul class="properties">
						<?php foreach ( $settings['properties'] as $index => $item ) : ?>
							<?php
								$keyOption = $this->get_repeater_setting_key( 'option', 'properties', $index );
								$keyValue  = $this->get_repeater_setting_key( 'value', 'properties', $index );
								$this->add_inline_editing_attributes( $keyOption );
								$this->add_inline_editing_attributes( $keyValue );
							?>
							<li class="properties__item">
								<div class="properties__name">
									<span <?php echo $this->get_render_attribute_string( $keyOption ); ?>><?php echo $item['option']; ?></span>
								</div>
								<div class="properties__value">
									<span <?php echo $this->get_render_attribute_string( $keyValue ); ?>><?php echo $item['value']; ?></span>
								</div>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
			<?php if ( $settings['enable_button'] && ! empty( $settings['button_title'] ) ) : ?>
				<div class="col-auto project__wrapper-button">
					<?php
						$this->add_render_attribute(
							'button',
							array(
								'class' => array( 'button', $settings['button_style'], $settings['button_color'], $settings['button_shadow'] ),
								'href'  => $settings['button_link']['url'],
							)
						);

					if ( $settings['button_link']['is_external'] ) {
						$this->add_render_attribute( 'button', 'target', '_blank' );
					}

					if ( $settings['button_link']['nofollow'] ) {
						$this->add_render_attribute( 'button', 'rel', 'nofollow' );
					}
					?>
					<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( 'button_title' ); ?>><?php echo $settings['button_title']; ?></span></a>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
		view.addInlineEditingAttributes( 'button_title' );
		#>
		<div class="d-flex justify-content-between align-items-center flex-wrap">
			<# if ( settings.properties.length ) { #>
				<div class="col-auto">
					<ul class="properties">
						<# _.each( settings.properties, function(item, index) { #>
							<#
								var keyOption = view.getRepeaterSettingKey( 'option', 'properties', index );
								var keyValue = view.getRepeaterSettingKey( 'value', 'properties', index );
								view.addInlineEditingAttributes( keyOption );
								view.addInlineEditingAttributes( keyValue );
							#>
							<li class="properties__item">
								<div class="properties__name">
								<span {{{ view.getRenderAttributeString( keyOption ) }}}>{{{ item.option }}}</span>
								</div>
								<div class="properties__value">
								<span {{{ view.getRenderAttributeString( keyValue ) }}}>{{{ item.value }}}</span>
								</div>
							</li>
						<# }); #>
					</ul>
				</div>
			<# } #>
			<# if ( settings.enable_button && settings.button_title ) { #>
				<div class="col-auto project__wrapper-button">
					<#
					view.addRenderAttribute(
							'button', {
								'class': [ 'button', settings.button_style, settings.button_color, settings.button_shadow ],
								'href': settings.button_link.url,
							}
						);

					if ( settings.button_link.is_external ) {
						view.addRenderAttribute( 'button', 'target', '_blank' );
					}

					if ( settings.button_link.nofollow ) {
						view.addRenderAttribute( 'button', 'rel', 'nofollow' );
					}
					#>
					<a {{{ view.getRenderAttributeString( 'button' ) }}}><span {{{ view.getRenderAttributeString( 'button_title' ) }}}>{{{ settings.button_title }}}</span></a>
				</div>
			<# } #>
		</div>
		<?php
	}
}
