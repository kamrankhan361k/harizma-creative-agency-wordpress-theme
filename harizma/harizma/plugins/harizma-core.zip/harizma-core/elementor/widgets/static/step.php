<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Step extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-step';
	}

	public function get_title() {
		return esc_html__( 'Step', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'text',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Description', 'harizma' ) ),
					'editor_type' => 'AREA',
				),
				array(
					'field'       => 'counter',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Counter', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Choose Image', 'harizma' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Heading...', 'harizma' ),
			)
		);

		$this->add_control(
			'text',
			array(
				'label'       => esc_html__( 'Description', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Description...', 'harizma' ),
			)
		);

		$this->add_control(
			'counter',
			array(
				'label'   => esc_html__( 'Counter', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( '01', 'harizma' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'harizma' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'is_height_equal',
			array(
				'label'       => esc_html__( 'Set height to the tallest card.', 'harizma' ),
				'description' => esc_html__( 'Useful if you have the cards of different heights. Applicable for the current row in layout.', 'harizma' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'selectors'   => array(
					'{{WRAPPER}}' => 'height: 100%;',
					'{{WRAPPER}} .elementor-widget-container' => 'height: 100%;',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'text' );
		$this->add_inline_editing_attributes( 'counter' );
		?>

		<div class="figure-process">
			<?php if ( ! empty( $settings['image']['url'] ) ) : ?>
				<?php

					$img = wp_get_attachment_image_src( $settings['image']['id'], 'full' );
					$this->add_render_attribute(
						'lazyWrapper',
						array(
							'class' => 'lazy',
							'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
						),
						true,
						true
					);
				?>

				<div class="figure-process__wrapper-icon">
					<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
						<img src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" data-src="<?php echo $img[0]; ?>" alt=""/>
					</div>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['heading'] ) ) : ?>
				<h4 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h4>
			<?php endif; ?>
			<?php if ( ! empty( $settings['text'] ) ) : ?>
				<p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo $settings['text']; ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $settings['counter'] ) ) : ?>
				<div class="figure-process__counter">
					<span <?php echo $this->get_render_attribute_string( 'counter' ); ?>><?php echo $settings['counter']; ?></span>
				</div>
			<?php endif; ?>
		</div>

		<?php
	}

	protected function content_template() {
		?>
			<#
				view.addInlineEditingAttributes( 'heading' );
				view.addInlineEditingAttributes( 'text' );
				view.addInlineEditingAttributes( 'counter' );
			#>

			<# if (settings.name) { #>
				<div>
					<h3 {{{ view.getRenderAttributeString( 'name' ) }}}>{{{ settings.name }}}</h3>
				</div>
			<# } #>
			<div class="figure-process">
				<# if ( settings.image.url ) { #>
					<div class="figure-process__wrapper-icon">
						<img class="lazy" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" data-src="{{{ settings.image.url }}}" alt=""/>
					</div>
				<# } #>
				<# if ( settings.heading ) { #>
					<h4 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h4>
				<# } #>
				<# if ( settings.text ) { #>
					<p {{{ view.getRenderAttributeString( 'text' ) }}}>{{{ settings.text }}}</p>
				<# } #>
				<# if ( settings.counter ) { #>
					<div class="figure-process__counter">
						<span {{{ view.getRenderAttributeString( 'counter' ) }}}>{{{ settings.counter }}}</span>
					</div>
				<# } #>
			</div>
		<?php
	}
}
