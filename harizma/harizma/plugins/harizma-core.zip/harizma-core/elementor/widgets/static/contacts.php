<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Contacts extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-contacts';
	}

	public function get_title() {
		return esc_html__( 'Contacts', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(),
			'integration-class' => 'WPML_Elementor_Harizma_Widget_Contacts',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'contacts_section',
			array(
				'label' => esc_html__( 'Contacts', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'icon',
			array(
				'label' => esc_html__( 'Icon', 'harizma' ),
				'type'  => Controls_Manager::ICON,
			)
		);

		$repeater->add_control(
			'contact',
			array(
				'label'   => esc_html__( 'Contact Info', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'hello@example.com', 'harizma' ),
			)
		);

		$repeater->add_control(
			'info',
			array(
				'label'   => esc_html__( 'Additional Info', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Send us a message', 'harizma' ),
			)
		);

		$this->add_control(
			'contacts',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ contact }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'form_section',
			array(
				'label' => esc_html__( 'Contact Form', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'shortcode',
			array(
				'label'       => esc_html__( 'Enter your shortcode', 'harizma' ),
				'description' => sprintf(
					'%1$s <a href="%2$s" target="_blank">%3$s</a> %3$s',
					esc_html__( 'You can get your contact form shorcode from', 'harizma' ),
					admin_url( 'admin.php?page=wpcf7' ),
					esc_html__( 'Contact Form 7 menu', 'harizma' ),
					esc_html__( 'in admin panel', 'harizma' )
				),
				'type'        => Controls_Manager::TEXTAREA,
				'render_type' => 'template',
				'placeholder' => 'Example: [contact-form-7 id="4" title="Harizma Contact Form Inline"]',
				'default'     => '',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings  = $this->get_settings_for_display();
		$shortcode = do_shortcode( shortcode_unautop( $settings['shortcode'] ) );

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'subheading' );
		?>

		<div class="container">
			<div class="row justify-content-between">
				<?php if ( ! empty( $shortcode ) ) : ?>
					<div class="col-lg-7 section-contacts__wrapper-form">
						<div class="form">
							<?php echo $shortcode; ?>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $settings['contacts'] ) ) : ?>
					<div class="col-lg-4 section-contacts__wrapper-contacts">
						<div class="figure-contact">
							<?php foreach ( $settings['contacts'] as $index => $item ) : ?>
								<?php
									$class = '';
								if ( ! empty( $item['icon'] ) ) {
									$class = 'figure-contact__item_flex';
								}
								?>
								<div class="figure-contact__item <?php echo $class; ?>">
									<?php
										$keyContact = $this->get_repeater_setting_key( 'contact', 'contacts', $index );
										$keyInfo    = $this->get_repeater_setting_key( 'info', 'contacts', $index );
										$this->add_inline_editing_attributes( $keyContact );
										$this->add_inline_editing_attributes( $keyInfo );
									?>
									<?php if ( ! empty( $item['icon'] ) ) : ?>
										<div class="figure-contact__icon <?php echo $item['icon']; ?>"></div>
									<?php endif; ?>
									<?php if ( ! empty( $item['contact'] ) || ! empty( $item['info'] ) ) : ?>
										<div class="figure-contact__item-inner">
											<?php if ( ! empty( $item['contact'] ) ) : ?>
												<div class="figure-contact__property"><span <?php echo $this->get_render_attribute_string( $keyContact ); ?>><?php echo $item['contact']; ?></span></div>
											<?php endif; ?>
											<?php if ( ! empty( $item['info'] ) ) : ?>
												<div class="figure-contact__value"><span <?php echo $this->get_render_attribute_string( $keyInfo ); ?>><?php echo $item['info']; ?></span></div>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<?php
	}
}
