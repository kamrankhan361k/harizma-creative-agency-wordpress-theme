<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Masonry_Grid extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-masonry-grid';
	}

	public function get_title() {
		return esc_html__( 'Masonry Grid & Gallery', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Images', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'gallery',
			array(
				'type'    => Controls_Manager::GALLERY,
				'default' => array(),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'harizma' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'lightbox',
			array(
				'label'   => esc_html__( 'Enable Lightbox', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'harizma' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'           => esc_html__( 'Columns', 'harizma' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => array(
					3  => esc_html__( 'Four Columns', 'harizma' ),
					4  => esc_html__( 'Three Columns', 'harizma' ),
					6  => esc_html__( 'Two Columns', 'harizma' ),
					12 => esc_html__( 'Single Column', 'harizma' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => esc_html__( 'Space Between', 'harizma' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 120,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 80,
				),
				'tablet_default'  => array(
					'size' => 30,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}} .grid'       => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item' => 'padding: calc({{SIZE}}{{UNIT}} / 2);',
				),
				'render_type'     => 'template',
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings    = $this->get_settings_for_display();
		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];
		$lightbox    = $settings['lightbox'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'itemAtts',
			array(
				'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);
		?>
		<div class="section-portfolio">
			<?php if ( ! empty( $settings['gallery'] ) ) : ?>
				<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
					<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
					<?php foreach ( $settings['gallery'] as $item ) : ?>
						<div <?php echo $this->get_render_attribute_string( 'itemAtts' ); ?>>
							<?php

							$img = wp_get_attachment_image_src( $item['id'], 'full' );
							$tag = 'div';

							$this->add_render_attribute(
								'linkAtts',
								array(
									'class' => 'grid__item-link',
								),
								true,
								true
							);

							if ( $settings['lightbox'] ) {
								$tag = 'a';
								$this->add_render_attribute(
									'linkAtts',
									array(
										'href' => $item['url'],
										'data-elementor-open-lightbox' => 'true',
										'data-elementor-lightbox-slideshow' => $this->get_id(),
									),
									true,
									true
								);
							}

							$this->add_render_attribute(
								'lazyWrapper',
								array(
									'class' => 'lazy-masonry',
									'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
								),
								true,
								true
							);

							?>
							<<?php echo $tag; ?> <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
								<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
									<img data-src="<?php echo $item['url']; ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt="">
								</div>
								<?php if ( $settings['lightbox'] ) : ?>
									<div class="grid__item-info">
										<div class="fa fa-search grid__item-icon"></div>
									</div>
									<div class="overlay overlay_accent-normal grid__item-overlay"></div>
								<?php endif; ?>
							</<?php echo $tag; ?>>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
