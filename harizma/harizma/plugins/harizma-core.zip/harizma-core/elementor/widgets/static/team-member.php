<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Team_Member extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-team-member';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'name',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Name', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'position',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Position', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'contacts',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Contacts', 'harizma' ) ),
					'editor_type' => 'AREA',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'avatar',
			array(
				'label'   => esc_html__( 'Choose Image', 'harizma' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'name',
			array(
				'label'       => esc_html__( 'Name', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'John Doe...', 'harizma' ),
			)
		);

		$this->add_control(
			'position',
			array(
				'label'       => esc_html__( 'Position', 'harizma' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'CEO...', 'harizma' ),
			)
		);

		$repeater = new Repeater();

		$this->add_control(
			'social_heading',
			array(
				'label'     => esc_html__( 'Social media', 'harizma' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$repeater->add_control(
			'social_link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
				'default'       => array(
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$repeater->add_control(
			'social_icon',
			array(
				'label' => esc_html__( 'Icon', 'harizma' ),
				'type'  => Controls_Manager::ICON,
			)
		);

		$this->add_control(
			'social',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ social_icon.replace("fa fa-", "") }}}',
				'prevent_empty' => false,
			)
		);

		$this->add_control(
			'contacts',
			array(
				'label'     => esc_html__( 'Contacts', 'harizma' ),
				'type'      => Controls_Manager::TEXTAREA,
				'rows'      => 10,
				'default'   => esc_html__( 'T: 8 800 555 35 35', 'harizma' ),
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'name' );
		$this->add_inline_editing_attributes( 'position' );
		$this->add_inline_editing_attributes( 'contacts' );

		$this->add_render_attribute( 'figure', 'class', 'figure-member' );

		if ( $settings['avatar']['url'] ) {

			$this->add_render_attribute( 'figure', 'class', 'figure-member_has-avatar' );

			if ( $settings['social'] || ! empty( $settings['contacts'] ) ) {
				$this->add_render_attribute( 'figure', 'class', 'figure-member_has-hover' );
			}
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'figure' ); ?>>
			<div class="figure-member__wrapper-img">
				<?php if ( ! empty( $settings['avatar']['url'] ) ) : ?>
					<?php
						$img = wp_get_attachment_image_src( $settings['avatar']['id'], 'full' );
						$this->add_render_attribute(
							'lazyWrapper',
							array(
								'class' => 'lazy',
								'style' => 'padding-bottom: calc( (' . $img[2] . '/' . $img[1] . ') * 100% ); height: 0;',
							),
							true,
							true
						);
					?>
					<div <?php echo $this->get_render_attribute_string( 'lazyWrapper' ); ?>>
						<img src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" data-src="<?php echo $img[0]; ?>" alt=""/>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $settings['social'] ) || ! empty( $settings['contacts'] ) ) : ?>
					<div class="figure-member__hover-content">
						<div class="figure-member__content">
							<?php if ( ! empty( $settings['contacts'] ) ) : ?>
								<p <?php echo $this->get_render_attribute_string( 'contacts' ); ?>><?php echo $settings['contacts']; ?></p>
							<?php endif; ?>
							<?php if ( ! empty( $settings['social'] ) && ! empty( $settings['contacts'] ) ) : ?>
								<div class="figure-member__line"></div>
							<?php endif; ?>
							<?php if ( ! empty( $settings['social'] ) ) : ?>
								<div class="figure-member__social">
									<ul class="social">
										<?php foreach ( $settings['social'] as $item ) : ?>
											<li class="social__item">
												<?php
													$target   = $item['social_link']['is_external'] ? ' target="_blank"' : '';
													$nofollow = $item['social_link']['nofollow'] ? ' rel="nofollow"' : '';
												?>
												<a class="social__icon <?php echo $item['social_icon']; ?>" href="<?php echo $item['social_link']['url']; ?>" <?php echo $target . ' ' . $nofollow; ?>></a>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
						<?php if ( ! empty( $settings['social'] ) || ! empty( $settings['contacts'] ) ) : ?>
							<div class="overlay overlay_accent-normal figure-member__overlay"></div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $settings['name'] ) || ! empty( $settings['position'] ) ) : ?>
				<div class="figure-member__wrapper-info">
					<?php if ( ! empty( $settings['name'] ) ) : ?>
						<div class="figure-member__name">
							<span <?php echo $this->get_render_attribute_string( 'name' ); ?>><?php echo $settings['name']; ?></span>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['position'] ) ) : ?>
						<div class="figure-member__position">
							<span <?php echo $this->get_render_attribute_string( 'position' ); ?>><?php echo $settings['position']; ?></span>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'name' );
			view.addInlineEditingAttributes( 'position' );
			view.addInlineEditingAttributes( 'contacts' );

			view.addRenderAttribute( 'figure', {
				'class': ['figure-member']
			});

			if ( settings.avatar.url ) {

				view.addRenderAttribute( 'figure', {
					'class': ['figure-member_has-avatar']
				});

				if ( settings.social.length || settings.contacts ) {

					view.addRenderAttribute( 'figure', {
						'class': ['figure-member_has-hover']
					});

				}

			}
		#>
		<div {{{ view.getRenderAttributeString( 'figure' ) }}}>
			<div class="figure-member__wrapper-img">
				<# if ( settings.avatar.url ) { #>
					<img class="lazy" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" data-src="{{{ settings.avatar.url }}}" alt=""/>
				<# } #>
				<# if ( settings.social.length || settings.contacts ) { #>
					<div class="figure-member__hover-content">
						<div class="figure-member__content">
							<# if ( settings.contacts ) { #>
								<p {{{ view.getRenderAttributeString( 'contacts' ) }}}>{{{ settings.contacts }}}</p>
							<# } #>
							<# if ( settings.social.length && settings.contacts ) { #>
								<div class="figure-member__line"></div>
							<# } #>
							<# if ( settings.social.length ) { #>
								<div class="figure-member__social">
									<ul class="social">
										<# _.each( settings.social, function(item) { #>
											<li class="social__item">
												<#
													var target = item.social_link.is_external ? ' target="_blank"' : '';
													var nofollow = item.social_link.nofollow ? ' rel="nofollow"' : '';
												#>
												<a class="social__icon {{{ item.social_icon }}}" href="{{{ item.social_link.url }}}" {{{ target }}} {{{ nofollow }}}></a>
										</li>
										<# }); #>
									</ul>
								</div>
							<# } #>
						</div>
						<# if ( settings.social.length || settings.contacts ) { #>
							<div class="overlay overlay_accent-normal figure-member__overlay"></div>
						<# } #>
					</div>
				<# } #>
			</div>
			<# if ( settings.name || settings.position ) { #>
				<div class="figure-member__wrapper-info">
					<# if ( settings.name ) { #>
						<div class="figure-member__name">
							<span {{{ view.getRenderAttributeString( 'name' ) }}}>{{{ settings.name }}}</span>
						</div>
					<# } #>
					<# if ( settings.position ) { #>
						<div class="figure-member__position">
							<span {{{ view.getRenderAttributeString( 'position' ) }}}>{{{ settings.position }}}</span>
						</div>
					<# } #>
				</div>
			<# } #>
		</div>
		<?php
	}
}
