<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Harizma_Widget_Background_Link extends Harizma_Widget_Base {
	protected static $_instance;

	public function get_name() {
		return 'harizma-widget-background-link';
	}

	public function get_title() {
		return esc_html__( 'Background Link', 'harizma' );
	}

	public function get_icon() {
		return 'eicon-plug hrz icon-harizma-logo hrz_accent';
	}

	public function get_categories() {
		return array( 'harizma-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'URL', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'subheading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Label', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'harizma' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'harizma' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'link',
			array(
				'label'         => esc_html__( 'Link', 'harizma' ),
				'type'          => Controls_Manager::URL,
				'show_external' => true,
			)
		);

		$this->add_control(
			'show_button',
			array(
				'label'   => esc_html__( 'Show Arrow Button', 'harizma' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'subheading',
			array(
				'label'   => esc_html__( 'Label', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Discover...', 'harizma' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'harizma' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Heading...', 'harizma' ),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'subheading' );

		$this->add_render_attribute(
			'link',
			array(
				'class' => array( 'aside-links__item' ),
				'href'  => $settings['link']['url'],
			)
		);

		if ( $settings['link']['is_external'] ) {
			$this->add_render_attribute( 'link', 'target', '_blank' );
		}

		if ( $settings['link']['nofollow'] ) {
			$this->add_render_attribute( 'link', 'rel', 'nofollow' );
		}
		?>

		<a <?php echo $this->get_render_attribute_string( 'link' ); ?>>
			<?php if ( ! empty( $settings['subheading'] ) ) : ?>
				<div class="aside-links__subheading">
					<span <?php echo $this->get_render_attribute_string( 'subheading' ); ?>><?php echo $settings['subheading']; ?></span>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['heading'] ) ) : ?>
				<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
			<?php endif; ?>
			<?php if ( $settings['show_button'] ) : ?>
				<div class="aside-links__wrapper-button">
					<div class="button button_white button_arrow">
						<span class="button__text button__text_line button__text_line-right"></span>
						<img class="button__icon" src="<?php echo get_theme_file_uri( 'img/general/triangle-right.svg' ); ?>" alt=""/>
					</div>
				</div>
			<?php endif; ?>
		</a>

		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'heading' );
			view.addInlineEditingAttributes( 'subheading' );

			view.addRenderAttribute(
				'link', {
					'class': [ 'aside-links__item' ],
					'href': settings.link.url,
				}
			);

			if ( settings.link.is_external ) {
				view.addRenderAttribute( 'link', 'target', '_blank' );
			}

			if ( settings.link.nofollow ) {
				view.addRenderAttribute( 'link', 'rel', 'nofollow' );
			}
		#>

		<a {{{ view.getRenderAttributeString( 'link' ) }}}>
			<# if ( settings.subheading ) { #>
				<div class="aside-links__subheading">
					<span {{{ view.getRenderAttributeString( 'subheading' ) }}}>{{{ settings.subheading }}}</span>
				</div>
			<# } #>
			<# if ( settings.heading ) { #>
				<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
			<# } #>
			<# if ( settings.show_button ) { #>
				<div class="aside-links__wrapper-button">
					<div class="button button_white button_arrow">
						<span class="button__text button__text_line button__text_line-right"></span>
						<img class="button__icon lazy" data-src="<?php echo get_theme_file_uri( 'img/general/triangle-right.svg' ); ?>" src="<?php echo get_theme_file_uri( 'img/general/lazy-placeholder.png' ); ?>" alt=""/>
					</div>
				</div>
			<# } #>
		</a>
		<?php
	}
}
