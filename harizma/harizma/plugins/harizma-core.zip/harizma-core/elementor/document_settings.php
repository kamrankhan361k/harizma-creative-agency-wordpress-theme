<?php

/**
 * Add new controls after end of "General Settings"
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );
function arts_add_elementor_document_settings_after_controls( \Elementor\Core\DocumentTypes\PageBase $page ) {
	$header_theme = get_theme_mod( 'header_theme', '' );
	$menu_style   = get_theme_mod( 'menu_style', 'regular' );

	/**
	 * Header Settings
	 */
	$page->start_controls_section(
		'header_section',
		array(
			'label' => esc_html__( 'Page Header', 'harizma' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		)
	);

	/**
	 * Override Header
	 */
	$page->add_control(
		'page_header_settings',
		array(
			'label'       => esc_html__( 'Override Page Header Settings', 'harizma' ),
			'description' => esc_html__( 'Use custom header settings for this page instead of global customizer settings', 'harizma' ),
			'type'        => \Elementor\Controls_Manager::SWITCHER,
			'default'     => '',
		)
	);

	/**
	 * Color Theme
	 */
	$page->add_control(
		'page_header_theme',
		array(
			'label'     => esc_html__( 'Color Theme', 'harizma' ),
			'type'      => \Elementor\Controls_Manager::SELECT,
			'options'   => array(
				''             => esc_html__( 'Black', 'harizma' ),
				'header_white' => esc_html__( 'White', 'harizma' ),
			),
			'default'   => esc_attr( $header_theme ),
			'condition' => array(
				'page_header_settings' => 'yes',
			),
		)
	);

	/**
	 * Menu Style
	 */
	$page->add_control(
		'page_menu_style',
		array(
			'label'     => esc_html__( 'Menu', 'harizma' ),
			'type'      => \Elementor\Controls_Manager::SELECT,
			'options'   => array(
				'regular'    => esc_html__( 'Regular', 'harizma' ),
				'fullscreen' => esc_html__( 'Fullscreen Overlay', 'harizma' ),
			),
			'default'   => esc_attr( $menu_style ),
			'condition' => array(
				'page_header_settings' => 'yes',
			),
		)
	);

	$page->end_controls_section();
}
