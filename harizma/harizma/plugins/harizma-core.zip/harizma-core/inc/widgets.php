<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'widgets_init', 'arts_register_widgets' );
function arts_register_widgets() {
	$widgets = array(
		'logo'      => 'Harizma_Widget_Logo',
		'social'    => 'Harizma_Widget_Social',
		'copyright' => 'Harizma_Widget_Copyright',
	);

	foreach ( $widgets as $index => $value ) {
		require_once __DIR__ . '/widgets/' . sanitize_key( $index ) . '-widget.php';
		register_widget( $value );
	}
}
