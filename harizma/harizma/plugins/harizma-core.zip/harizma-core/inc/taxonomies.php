<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'init', 'arts_register_taxonomies' );
function arts_register_taxonomies() {
	/**
	 * Portfolio Category
	 */
	$labels = array(
		'name'              => _x( 'Portfolio Categories', 'taxonomy general name', 'harizma' ),
		'singular_name'     => _x( 'Portfolio Category', 'taxonomy singular name', 'harizma' ),
		'search_items'      => esc_html__( 'Search Portfolio Categories', 'harizma' ),
		'all_items'         => esc_html__( 'All Portfolio Categories', 'harizma' ),
		'parent_item'       => esc_html__( 'Parent Portfolio Category', 'harizma' ),
		'parent_item_colon' => esc_html__( 'Parent Portfolio Category:', 'harizma' ),
		'edit_item'         => esc_html__( 'Edit Category', 'harizma' ),
		'update_item'       => esc_html__( 'Update Category', 'harizma' ),
		'add_new_item'      => esc_html__( 'Add New Category', 'harizma' ),
		'new_item_name'     => esc_html__( 'New Category Name', 'harizma' ),
		'menu_name'         => esc_html__( 'Category', 'harizma' ),
	);
	$args   = array(
		'labels'             => $labels,
		'description'        => esc_html__( '', 'harizma' ),
		'hierarchical'       => false,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_nav_menus'  => true,
		'show_tagcloud'      => true,
		'show_in_quick_edit' => true,
		'show_admin_column'  => true,
		'show_in_rest'       => true,
	);
	register_taxonomy( 'portfolio_category', array( 'arts_portfolio_item' ), $args );
}
