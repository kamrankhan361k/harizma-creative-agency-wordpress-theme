<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Widget Social
 */
class Harizma_Widget_Logo extends WP_Widget {
	function __construct() {
		parent::__construct(
			'harizma_logo',
			__( 'Harizma: Logo', 'harizma' ),
			array( 'description' => esc_html__( 'Displays site logotype', 'harizma' ) )
		);
	}

	/**
	 * Display widget on frontend
	 *
	 * @param array $args     widget arguments.
	 * @param array $instance saved data from settings
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];
		get_template_part( 'template-parts/logo/logo' );
		echo $args['after_widget'];
	}
}
