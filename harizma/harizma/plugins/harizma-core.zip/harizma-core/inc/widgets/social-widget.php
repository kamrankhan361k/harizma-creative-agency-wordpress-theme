<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Widget Social
 */
class Harizma_Widget_Social extends WP_Widget {
	function __construct() {
		parent::__construct(
			'harizma_social',
			__( 'Harizma: Social Media', 'harizma' ),
			array( 'description' => esc_html__( 'Displays social media links', 'harizma' ) )
		);

		$this->socials = array(
			'facebook'    => array(
				'title' => esc_html__( 'Facebook URL', 'harizma' ),
				'icon'  => 'fa fa-facebook-f fa-fw',
			),
			'twitter'     => array(
				'title' => esc_html__( 'Twitter URL', 'harizma' ),
				'icon'  => 'fa fa-twitter fa-fw',
			),
			'instagram'   => array(
				'title' => esc_html__( 'Instagram URL', 'harizma' ),
				'icon'  => 'fa fa-instagram fa-fw',
			),
			'linkedin'    => array(
				'title' => esc_html__( 'LinkedIn URL', 'harizma' ),
				'icon'  => 'fa fa-linkedin fa-fw',
			),
			'google_plus' => array(
				'title' => esc_html__( 'Google Plus URL', 'harizma' ),
				'icon'  => 'fa fa-google-plus fa-fw',
			),
			'vk'          => array(
				'title' => esc_html__( 'VK URL', 'harizma' ),
				'icon'  => 'fa fa-vk fa-fw',
			),
			'youtube'     => array(
				'title' => esc_html__( 'YouTube URL', 'harizma' ),
				'icon'  => 'fa fa-youtube fa-fw',
			),
			'vimeo'       => array(
				'title' => esc_html__( 'Vimeo URL', 'harizma' ),
				'icon'  => 'fa fa-vimeo fa-fw',
			),
			'dribbble'    => array(
				'title' => esc_html__( 'Dribbble URL', 'harizma' ),
				'icon'  => 'fa fa-dribbble fa-fw',
			),
			'pinterest'   => array(
				'title' => esc_html__( 'Pinterest URL', 'harizma' ),
				'icon'  => 'fa fa-pinterest fa-fw',
			),
			'behance'     => array(
				'title' => esc_html__( 'Behance URL', 'harizma' ),
				'icon'  => 'fa fa-behance fa-fw',
			),
			'flickr'      => array(
				'title' => esc_html__( 'Flickr URL', 'harizma' ),
				'icon'  => 'fa fa-flickr fa-fw',
			),
			'tumblr'      => array(
				'title' => esc_html__( 'Tumblr URL', 'harizma' ),
				'icon'  => 'fa fa-tumblr fa-fw',
			),
			'vine'        => array(
				'title' => esc_html__( 'Vine URL', 'harizma' ),
				'icon'  => 'fa fa-vine fa-fw',
			),
			'github'      => array(
				'title' => esc_html__( 'Github URL', 'harizma' ),
				'icon'  => 'fa fa-github fa-fw',
			),
			'soundcloud'  => array(
				'title' => esc_html__( 'SoundCloud URL', 'harizma' ),
				'icon'  => 'fa fa-soundcloud fa-fw',
			),
		);
	}

	/**
	 * Social Medias
	 *
	 * @var array
	 */
	private $socials;

	/**
	 * Display widget on frontend
	 *
	 * @param array $args     widget arguments.
	 * @param array $instance saved data from settings
	 */
	function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$widget_id = $args['widget_id'];

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		?>
			<ul class="social">
				<?php foreach ( $this->socials as $index => $item ) : ?>
					<?php $option = @ $instance[ $index ] ? : ''; ?>
					<?php if ( ! empty( $option ) ) : ?>
						<li class="social__item">
							<a class="social__icon <?php echo esc_attr( $item['icon'] ); ?>" href="<?php echo esc_url( $option ); ?>" target="_blank"></a>
						</li>
					<?php endif; ?>
				<?php endforeach; ?>
			</ul>
		<?php
		echo $args['after_widget'];
	}

	/**
	 * Admin settings
	 *
	 * @param array $instance saved data from settings
	 */
	function form( $instance ) {
		$title = @ $instance['title'] ? : '';
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'harizma' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<br>
		<?php foreach ( $this->socials as $index => $item ) : ?>
			<?php
					$field_name  = $this->get_field_name( $index );
					$field_value = @ $instance[ $index ] ? : '';
					$field_id    = $this->get_field_id( $index );
					$field_title = $item['title'];
			?>
				<p>
					<label for="<?php echo esc_html( $field_id ); ?>"><?php echo esc_html( $item['title'] ); ?></label> 
					<input class="widefat" id="<?php echo esc_html( $field_id ); ?>" name="<?php echo esc_html( $field_name ); ?>" type="text" value="<?php echo esc_url( $field_value ); ?>">
				</p>
		<?php endforeach; ?>
		<?php
	}

	/**
	 * Sanitize and save widget settings.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance new settings
	 * @param array $old_instance previous settings
	 *
	 * @return array data to save
	 */
	function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		foreach ( $this->socials as $index => $item ) {
			$url                = $new_instance[ $index ];
			$instance[ $index ] = '';

			if ( ! empty( $url ) ) {
				$instance[ $index ] = esc_url( $url );
			}
		}
		return $instance;
	}
}
