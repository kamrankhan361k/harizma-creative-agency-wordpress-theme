<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'init', 'arts_register_post_types' );
function arts_register_post_types() {
	$priority = 5;

	/**
	 * Portfolio
	 */
	$labels  = array(
		'name'                  => _x( 'Portfolio Items', 'Post Type General Name', 'harizma' ),
		'singular_name'         => _x( 'Portfolio Item', 'Post Type Singular Name', 'harizma' ),
		'menu_name'             => _x( 'Portfolio Items', 'Admin Menu text', 'harizma' ),
		'name_admin_bar'        => _x( 'Portfolio Item', 'Add New on Toolbar', 'harizma' ),
		'archives'              => esc_html__( 'Portfolio Item Archives', 'harizma' ),
		'attributes'            => esc_html__( 'Portfolio Item Attributes', 'harizma' ),
		'parent_item_colon'     => esc_html__( 'Parent Portfolio Item:', 'harizma' ),
		'all_items'             => esc_html__( 'All Portfolio Items', 'harizma' ),
		'add_new_item'          => esc_html__( 'Add New Portfolio Item', 'harizma' ),
		'add_new'               => esc_html__( 'Add New', 'harizma' ),
		'new_item'              => esc_html__( 'New Portfolio Item', 'harizma' ),
		'edit_item'             => esc_html__( 'Edit Portfolio Item', 'harizma' ),
		'update_item'           => esc_html__( 'Update Portfolio Item', 'harizma' ),
		'view_item'             => esc_html__( 'View Portfolio Item', 'harizma' ),
		'view_items'            => esc_html__( 'View Portfolio Items', 'harizma' ),
		'search_items'          => esc_html__( 'Search Portfolio Item', 'harizma' ),
		'not_found'             => esc_html__( 'Not found', 'harizma' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'harizma' ),
		'featured_image'        => esc_html__( 'Featured Image', 'harizma' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'harizma' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'harizma' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'harizma' ),
		'insert_into_item'      => esc_html__( 'Insert into Portfolio Item', 'harizma' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this Portfolio Item', 'harizma' ),
		'items_list'            => esc_html__( 'Portfolio Items list', 'harizma' ),
		'items_list_navigation' => esc_html__( 'Portfolio Items list navigation', 'harizma' ),
		'filter_items_list'     => esc_html__( 'Filter Portfolio Items list', 'harizma' ),
	);
	$rewrite = array(
		'slug'       => 'portfolio',
		'with_front' => true,
		'pages'      => true,
		'feeds'      => true,
	);
	$args    = array(
		'label'               => esc_html__( 'Portfolio Item', 'harizma' ),
		'description'         => esc_html__( '', 'harizma' ),
		'labels'              => $labels,
		'menu_icon'           => 'dashicons-art',
		'supports'            => array( 'title', 'thumbnail' ),
		'taxonomies'          => array( 'portfolio_category' ),
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => $priority++,
		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => true,
		'can_export'          => true,
		'has_archive'         => false,
		'hierarchical'        => false,
		'exclude_from_search' => false,
		'show_in_rest'        => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
		'rewrite'             => $rewrite,
	);
	register_post_type( 'arts_portfolio_item', $args );

	/**
	 * Services
	 */
	$labels  = array(
		'name'                  => _x( 'Services', 'Post Type General Name', 'harizma' ),
		'singular_name'         => _x( 'Service', 'Post Type Singular Name', 'harizma' ),
		'menu_name'             => _x( 'Services', 'Admin Menu text', 'harizma' ),
		'name_admin_bar'        => _x( 'Service', 'Add New on Toolbar', 'harizma' ),
		'archives'              => esc_html__( 'Service Archives', 'harizma' ),
		'attributes'            => esc_html__( 'Service Attributes', 'harizma' ),
		'parent_item_colon'     => esc_html__( 'Parent Service:', 'harizma' ),
		'all_items'             => esc_html__( 'All Services', 'harizma' ),
		'add_new_item'          => esc_html__( 'Add New Service', 'harizma' ),
		'add_new'               => esc_html__( 'Add New', 'harizma' ),
		'new_item'              => esc_html__( 'New Service', 'harizma' ),
		'edit_item'             => esc_html__( 'Edit Service', 'harizma' ),
		'update_item'           => esc_html__( 'Update Service', 'harizma' ),
		'view_item'             => esc_html__( 'View Service', 'harizma' ),
		'view_items'            => esc_html__( 'View Services', 'harizma' ),
		'search_items'          => esc_html__( 'Search Service', 'harizma' ),
		'not_found'             => esc_html__( 'Not found', 'harizma' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'harizma' ),
		'featured_image'        => esc_html__( 'Featured Image', 'harizma' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'harizma' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'harizma' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'harizma' ),
		'insert_into_item'      => esc_html__( 'Insert into Service', 'harizma' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this Service', 'harizma' ),
		'items_list'            => esc_html__( 'Services list', 'harizma' ),
		'items_list_navigation' => esc_html__( 'Services list navigation', 'harizma' ),
		'filter_items_list'     => esc_html__( 'Filter Services list', 'harizma' ),
	);
	$rewrite = array(
		'slug'       => 'services',
		'with_front' => true,
		'pages'      => true,
		'feeds'      => true,
	);
	$args    = array(
		'label'               => esc_html__( 'Service', 'harizma' ),
		'description'         => esc_html__( '', 'harizma' ),
		'labels'              => $labels,
		'menu_icon'           => 'dashicons-hammer',
		'supports'            => array( 'title', 'thumbnail' ),
		'taxonomies'          => array(),
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => $priority++,
		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => true,
		'can_export'          => true,
		'has_archive'         => false,
		'hierarchical'        => false,
		'exclude_from_search' => false,
		'show_in_rest'        => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
		'rewrite'             => $rewrite,
	);
	register_post_type( 'arts_service', $args );
}

