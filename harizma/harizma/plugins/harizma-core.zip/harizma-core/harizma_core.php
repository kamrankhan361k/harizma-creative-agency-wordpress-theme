<?php
/**
 * Plugin Name: Harizma Core
 * Description: Core Plugin for Harizma WordPress Theme
 * Plugin URI:  https://artemsemkin.com/
 * Version:     2.3.0
 * Author:      Artem Semkin
 * Author URI:  https://artemsemkin.com/
 * Text Domain: harizma
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once __DIR__ . '/elementor/harizma_elementor_extension.php';
require_once __DIR__ . '/elementor/document_settings.php';
require_once __DIR__ . '/inc/cpt.php';
require_once __DIR__ . '/inc/helper_functions.php';
require_once __DIR__ . '/inc/options.php';
require_once __DIR__ . '/inc/widgets.php';
require_once __DIR__ . '/inc/taxonomies.php';
require_once __DIR__ . '/inc/metaboxes/service_metaboxes.php';
require_once __DIR__ . '/inc/metaboxes/page_metaboxes.php';
require_once __DIR__ . '/inc/metaboxes/portfolio_metaboxes.php';

add_action( 'init', 'arts_load_textdomain' );
function arts_load_textdomain() {
	load_plugin_textdomain( 'harizma' );
}
